package com.example.guidegreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NavUtils;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import  android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import static java.lang.Thread.sleep;

public class frgnurseries2 extends Fragment {
    ListView list;
    ImageButton delete;
    ArrayList<Bitmap> imges;

    public frgnurseries2() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = (View) inflater.inflate(R.layout.frglistnerseries2, container, false);
        list = v.findViewById(R.id.listners2);
        LinearLayout ly = v.findViewById(R.id.addnewners);
        Button addnew = new Button(getContext());
        addnew.setText("Add new nursery");
        addnew.setTextSize(17);
        addnew.setWidth(500);
        ly.addView(addnew, 0);
        addnew.setBackgroundResource(R.drawable.rounded_button);
        delete = new ImageButton(getContext());
        ly.addView(delete);
        delete.setImageResource(R.drawable.ic_delete_black_24dp);
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) delete.getLayoutParams();
        params.leftMargin = 350;
        delete.setBackgroundColor(0xFFFFFFF);
        getNurseryImage getNurseryImage = new getNurseryImage();
        getNurseryImage.execute();
        async asc = new async(getContext(), list);
        asc.execute();



        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // designToDelete designToDelete = new designToDelete();
                deletenursery deletenursery = new deletenursery();
                FragmentTransaction t = getFragmentManager().beginTransaction();
                t.replace(R.id.frame1, deletenursery);
                t.addToBackStack(null);
                t.commit();
            }
        });

        addnew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newNursery newNursery = new newNursery();
                FragmentTransaction t = getFragmentManager().beginTransaction();
                t.replace(R.id.frame1, newNursery);
                t.addToBackStack(null);
                t.commit();
            }
        });

        return v;
    }

    public class custumAdapter extends BaseAdapter {
        ArrayList<String> lo;
        ArrayList<String> na;
        ArrayList<String> ph;
        Context c;
        ArrayList<Bitmap> images;

        public custumAdapter(ArrayList l, ArrayList p, ArrayList n, ArrayList images) {
            this.lo = l;
            this.ph = p;
            this.na = n;
            this.images = images;
        }

        @Override
        public int getCount() {
            return lo.size();

        }

        @Override
        public String getItem(int position) {
            return ph.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.frgnurseries, null);
            ImageView imgView = convertView.findViewById(R.id.imgView2);
            TextView txtname = convertView.findViewById(R.id.name2);
            TextView txtlocation = convertView.findViewById(R.id.location2);
            TextView txtphone = convertView.findViewById(R.id.phone2);
            txtname.setText(na.get(position));
            txtlocation.setText(lo.get(position));
            txtphone.setText(ph.get(position));
            imgView.setImageBitmap(imges.get(position));
            return convertView;
        }
    }

    class async extends AsyncTask<Void, String, String> {
        ListView v;
        String result = "", line = "", result2 = "", line2 = "";
        BufferedReader rd;
        ArrayList<String> p, n, l;
        TextView t;
        Context c;
        Bitmap bitmap;
        ProgressDialog loading;
        ArrayList<Bitmap> images;
        AlertDialog.Builder dialog;
        ImageButton delete;

        public async(Context c, ListView v) {
            this.c = c;
            this.v = v;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(c, "Downloading data...", "Please wait...", false, false);
        }

        @Override
        protected String doInBackground(Void... voids) {

            try {
                String address = "http://192.168.0.108:1880/agri/getNurseries.php";
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                //  t.setText(e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            n = new ArrayList<String>();
            p = new ArrayList<String>();
            l = new ArrayList<String>();
            String[] z = s.split("hihi");
            for (int k = 0; k < z.length; k++) {
                int d = z[k].indexOf('&');
                String sub = z[k].substring(d + 1);
                int d2 = sub.indexOf('*');
                String txtphone = sub.substring(0, d2);
                String txtlocation = sub.substring(d2 + 1);
                String txtname = z[k].substring(0, d);
                p.add(txtphone);
                l.add(txtname);
                n.add(txtlocation);
            }
            final custumAdapter ad = new custumAdapter(n, p, l,imges);
            v.setAdapter(ad);
            v.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                    dialog = new AlertDialog.Builder(getActivity());
                    dialog.setMessage("+961 "+p.get(position));
                    dialog.setTitle("Do you want to call this number ?\n");
                    dialog.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Uri number = Uri.parse("tel:+961" + p.get(position));
                            Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
                            startActivity(callIntent);
                        }
                    });
                    //Toast.makeText(c, ""+images.get(0), Toast.LENGTH_SHORT).show();
                    dialog.create().show();
                }
            });
        }
    }

    class getNurseryImage extends AsyncTask<Void, Void, Void> {
        Bitmap bitmap;
        //String line, imgres;
        StringBuilder res;

        @Override
        protected Void doInBackground(Void... voids) {
            String line = "", result = "";
            Bitmap BT = null;
            try {
                URL url = new URL("http://192.168.0.108:1880/agri/nurseryImageCount.php");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                res = new StringBuilder();
                while ((line = rd.readLine()) != null) {
                    result += line;

                }
            } catch (Exception e) {
                //return  e.getCause();
            }
            imges=new ArrayList<>();
            for(int i=1;i<=Integer.parseInt(result);i++) {
                try {
                    String x = "http://192.168.0.108:1880/agri/nurseryImage.php?&idNursery="+i;
                    BT = BitmapFactory.decodeStream((InputStream)
                            new URL(x).getContent());
                    if(!BT.equals(""))
                        imges.add(BT);
                } catch (Exception e) {
                }
            }
            return null;
            //  return BT;
        }

        @Override
        protected void onPostExecute(Void v) {
            super.onPostExecute(v);
        }
    }
}
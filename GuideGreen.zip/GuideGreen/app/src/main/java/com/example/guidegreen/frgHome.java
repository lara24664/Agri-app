package com.example.guidegreen;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import  android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;


public class frgHome extends Fragment {
    ImageView ab,back;
    public frgHome() {
    }

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.frghomelayout2, container, false);
        back=v.findViewById(R.id.back2);
        ab=v.findViewById(R.id.about);
        CardView prd=v.findViewById(R.id.toPrd);
        CardView asmede=v.findViewById(R.id.toAsmede);
        CardView plantTech=v.findViewById(R.id.plantingTechnique);
        CardView nurseries=v.findViewById(R.id.toNurseries);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                loginPage l=new loginPage();
                l.e1.getText().clear();
                l.e2.getText().clear();
                transaction.replace(R.id.frame1,l);
                transaction.addToBackStack(null);
                transaction.commit();

            }
        });
        ab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
                dialog.setTitle("About us");
                dialog.setMessage("Developped by:Lara kojok & Fatima Safa !");
                dialog.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                dialog.create().show();

            }
        });
     nurseries.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             FragmentTransaction t = getFragmentManager().beginTransaction();
             frgnurseries2 frgnurseries=new frgnurseries2 ();
             t.replace(R.id.frame1,frgnurseries);
             t.addToBackStack(null);
             t.commit();
         }
     });
        asmede.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                fragEngrais1 fragEngrais=new fragEngrais1();
                t.replace(R.id.frame1,fragEngrais);
                t.addToBackStack(null);
                t.commit();
            }
        });
        plantTech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                frglistplant2 frglistplant=new frglistplant2();
                //frgplanttech frgplanttech=new frgplanttech();
                t.replace(R.id.frame1,frglistplant);
                t.addToBackStack(null);
                t.commit();
            }
        });
        prd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                frgcategories b=new frgcategories();
                t.replace(R.id.frame1,b);
                t.addToBackStack(null);
                t.commit();
            }
        });

        return v;
    }

}

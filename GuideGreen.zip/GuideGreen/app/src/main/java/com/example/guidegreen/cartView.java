package com.example.guidegreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class cartView extends Fragment {
    RecyclerView r;
    String maxQuan;
    String prixeach;
    private CartAdapter g;
    TextView totall;
    int id;
    float totalPrice;
    String nom;
    String idProd;
    int idpr=0;
    Button Confirm;
    String  user="";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.cart_layout, container, false);
        r=v.findViewById(R.id.recycler_cart);
        totall=v.findViewById(R.id.tv_total);
       id=this.getArguments().getInt("idPanier");
       user=this.getArguments().getString("user");
       Confirm=v.findViewById(R.id.btn_placeorder);
       Confirm.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               FragmentTransaction t = getFragmentManager().beginTransaction();
              ConfirmOrder confirmOrder=new ConfirmOrder();
              Bundle b=new Bundle();
              b.putString("usern",user);
              b.putInt("idPanier",id);
              b.putFloat("totalPrix",totalPrice);
              confirmOrder.setArguments(b);
               t.replace(R.id.frame1,confirmOrder);
               t.addToBackStack(null);
               t.commit();
           }
       });
        Toast.makeText(getContext(),""+id,Toast.LENGTH_SHORT).show();
        getTotalPrice getTotalPrice=new getTotalPrice();
        getTotalPrice.execute();
       // totall.setText(""+totalPrice+"L.B.P");
        r.setLayoutManager(new LinearLayoutManager(getContext()));
        asyncProducts asyncProducts=new asyncProducts(getContext(),r);
        asyncProducts.execute();
        return v;
    }
    public class CartAdapter extends RecyclerView.Adapter<CartAdapter.GroceryProductViewHolder> {
        ArrayList<String> name,price,quantitty,idProduct;
        //ArrayList<Bitmap>ima;
        Context context;

        public CartAdapter(ArrayList name,ArrayList price,ArrayList quantitty, Context context) {
            this.name = name;
            this.price=price;
            this.quantitty=quantitty;
            this.context = context;
        }

        @Override
        public cartView.CartAdapter.GroceryProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            //inflate the layout file
            View groceryProductView = getLayoutInflater().inflate(R.layout.card_cart,null);
            cartView.CartAdapter.GroceryProductViewHolder gvh = new CartAdapter.GroceryProductViewHolder(groceryProductView);
            return gvh;
        }

        @Override
        public void onBindViewHolder(final cartView.CartAdapter.GroceryProductViewHolder holder, final int position) {
            holder.txtProductName.setText(name.get(position));
            holder.txtProductPrice.setText(price.get(position));
            holder.txtProductqu.setText(quantitty.get(position));
            holder.delete.setTag(name.get(position));

           nom=name.get(position);
            //asyncmaxqu asyncmaxqu=new asyncmaxqu();
           // asyncmaxqu.execute();
            //asynprix asynprix=new asynprix();
           // asynprix.execute();
            getIdProd g=new getIdProd();
            g.execute("http://192.168.0.108:1880/agri/getIdOfProdu.php?name="+holder.txtProductName.getText().toString());


            holder.plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   /* String pric=holder.txtProductPrice.getText().toString();
                    String prix=pric.split(" ")[0];
                    float p=Float.valueOf(prix);*/
                   int p=Integer.parseInt(prixeach);
                    float qu=Float.parseFloat(holder.txtProductqu.getText().toString());
                    if(qu<Float.parseFloat(maxQuan))
                    {
                        qu+=1.0;
                        holder.txtProductqu.setText(String.valueOf(qu));

                        holder.txtProductPrice.setText(""+p*qu+"");
                    }
                    else
                    {
                        holder.plus.setEnabled(true);

                    }
                }
            });


            holder.minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int p=Integer.parseInt(prixeach);
                    float qu=Float.parseFloat(holder.txtProductqu.getText().toString());
                    if(qu>1.0)
                    {
                        qu-=1.0;
                        holder.txtProductqu.setText(String.valueOf(qu));

                        holder.txtProductPrice.setText(""+p*qu+"");
                    }
                    else
                    {
                        holder.minus.setEnabled(true);

                    }

                }
            });
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    /**/
                    GroceryProductViewHolder hold = (GroceryProductViewHolder) v.getTag();
                    final int position = hold.getPosition();
                    AlertDialog myQuittingDialogBox =new AlertDialog.Builder(context)
                            //set message, title, and icon
                            .setTitle("Delete")
                            .setMessage("Do you want to Delete"+holder.delete.getTag())
                            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface dialog, int whichButton) {
                                    deleteAsync a=new deleteAsync();
                                    a.execute("http://192.168.0.108:1880/agri/deleteFromCart.php?&idProd="+Integer.parseInt(idProd)+"&idPan="+id);
                                    name.remove(holder.getAdapterPosition());
                                    price.remove(holder.getAdapterPosition());
                                    quantitty.remove(holder.getAdapterPosition());
                                    getTotalPrice getTotalPrice=new getTotalPrice();
                                    getTotalPrice.execute();
                                    notifyItemRemoved(holder.getAdapterPosition());
                                    notifyItemRangeChanged(holder.getAdapterPosition(), name.size());
                                    dialog.dismiss();

                                }

                            })
                            .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {

                                    dialog.dismiss();

                                }
                            })
                            .create();
                    myQuittingDialogBox.show();


                }
            });



            holder.delete.setTag(holder);
            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   /* asynprix asynprix=new asynprix();
                    asynprix.execute();
                    Toast.makeText(getContext(),""+prixeach,Toast.LENGTH_SHORT).show();
                    //nom="";*/
                   Toast.makeText(getContext(),""+holder.txtProductName.getText().toString(),Toast.LENGTH_SHORT).show();
                }
            });

        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public int getItemCount() {
            return name.size();
        }
        class GroceryProductViewHolder extends RecyclerView.ViewHolder {
            ImageView plus,minus,delete;
            TextView txtProductName;
            TextView txtProductPrice;
            TextView txtProductqu;
CardView cardView;

            // TextView txtProductQty;
            public GroceryProductViewHolder(View view) {
                super(view);
                minus = view.findViewById(R.id.MinusICon);
                plus=view.findViewById(R.id.PlusIcon);
                txtProductName = view.findViewById(R.id.nameProduct);
                txtProductPrice = view.findViewById(R.id.priceProducts);
                txtProductqu = view.findViewById(R.id.ProductQty);
               delete=view.findViewById(R.id.deleteCart);
               cardView=view.findViewById(R.id.idCardView);
                //  txtProductQty = view.findViewById(R.id.idProductQty);
            }
        }
    }
    public class asyncmaxqu extends AsyncTask<Void,String,String>
    {
        String line="",result="";
        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/quantite.php?&name="+nom;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {

            }
            return result;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            maxQuan=s;
           // Toast.makeText(getContext(),""+maxQuan,Toast.LENGTH_SHORT).show();
        }
    }
    public class asynprix extends AsyncTask<Void,String,String>
    {
        String line="",result="";
        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/getPrixEachProd.php?&name="+nom;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {

            }
            return result;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
           prixeach=s;
         //   Toast.makeText(getContext(),""+prixeach,Toast.LENGTH_SHORT).show();
        }
    }
    public class asyncProducts extends AsyncTask<Void,String,String> {

        RecyclerView v;
        String result = "", line = "", result2 = "", line2 = "";
        BufferedReader rd;
        ArrayList<String> p, n, l,idproduct;
        //List<Grocery> mProductList;
        TextView t;
        Context c;
        //Bitmap bitmap;
        ProgressDialog loading;
        //AlertDialog.Builder dialog;
        //ImageButton delete;

        asyncProducts(Context c, RecyclerView v) {
            this.c = c;
            this.v = v;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(c, "Downloading data...", "Please wait...", false, false);
        }

        @Override
        protected String doInBackground(Void... voids) {

            try {
                String address = "http://192.168.0.108:1880/agri/getCart.php?&idPan="+id;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            //Toast.makeText(getContext(),""+s,Toast.LENGTH_SHORT).show();
          //  mProductList = new ArrayList<>();
            n = new ArrayList<String>();
            p = new ArrayList<String>();
            l = new ArrayList<String>();
         //   Toast.makeText(getContext(), "" + s, Toast.LENGTH_SHORT).show();
            String[] z = s.split("%fi%");
            for (int k = 0; k < z.length; k++) {
                int d = z[k].indexOf('+');
                String sub = z[k].substring(d + 1);
                int d2 = sub.indexOf('<');
                String price= sub.substring(0, d2)+"L.B.P";
                String quantity = sub.substring(d2 + 1);
                String txtname = z[k].substring(0, d);
                n.add(txtname);
                p.add(price);
                l.add(quantity);

            }
            ArrayList<String> lll=new ArrayList<>();
            for (int j=0;j<n.size();j++) {
                lll.add(n.get(j));
            }
            g=new cartView.CartAdapter(n,p,l,getContext());
            v.setAdapter(g);
//Toast.makeText(getContext(),""+g.price.toString()+" //// "+g.name.toString()+"---------"+g.quantitty.toString(),Toast.LENGTH_SHORT).show();

        }
    }
    public class getTotalPrice extends AsyncTask<Void,String,String>{
        String line="",result="";

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/selectTotal.php?&idPan="+id;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
           // super.onPostExecute(s);
            String []x=s.split("end");
            float nb=0;
            for (int i=0;i<x.length;i++)
            {
                nb+=Float.valueOf(x[i]);
            }
            totalPrice=nb;
            totall.setText(totalPrice+"L.B.P");
        }
    }
    public class deleteAsync extends AsyncTask<String,String,String>{
        String line="",result="";
        ProgressDialog loading;
        Context c;
        protected void onPreExecute() {
            super.onPreExecute();
           // loading = ProgressDialog.show(c, "Delete From Cart...", "Please wait...", false, false);
        }
        @Override
        protected String doInBackground(String... strings) {

            try {
              //  String address = "http://192.168.0.113:1880/agri/deleteFromCart.php?&idProd="+idProd+"&idPan="+id;
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
          //  loading.dismiss();
            Toast.makeText(getContext(),""+s,Toast.LENGTH_SHORT).show();
        }
    }
    class getIdProd extends AsyncTask<String,String,String>{

        @Override
        protected String doInBackground(String... strings) {
String result="",line="";
            try {
                //String address = "http://192.168.0.113:1880/agri/deleteFromCart.php?&idProd="+idProd+"&idPan="+id;
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            idProd=s;
        }
    }


}

package com.example.guidegreen;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class registerPage extends Fragment {
    Button register;
    EditText First_Name, Last_Name, Email,Phone ,Username, Password ,Adresse;
    Spinner type;
    registerPage(){}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View v=inflater.inflate(R.layout.registerpage,container,false);
        First_Name = (EditText)v.findViewById(R.id.firstname);
        Last_Name = (EditText)v.findViewById(R.id.lastname);
        Email = (EditText)v.findViewById(R.id.email);
        Phone=(EditText)v.findViewById(R.id.phone) ;
        Username=(EditText)v.findViewById(R.id.username);
        Password = (EditText)v.findViewById(R.id.password);
        Adresse=(EditText)v.findViewById(R.id.adresse);
        register = (Button)v.findViewById(R.id.signUp);
        type=(Spinner)v.findViewById(R.id.spintype);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String lname=Last_Name.getText().toString();
                String fname=First_Name.getText().toString();
                String adresse=Adresse.getText().toString();
                String email=Email.getText().toString();
                String phone=Phone.getText().toString();
                String username=Username.getText().toString();
                String passweord=Password.getText().toString();
                String typ=type.getSelectedItem().toString();
                if(lname.equals("")||fname.equals("")||adresse.equals("")||email.equals("")||phone.equals("")||username.equals("")||passweord.equals(""))
                {
                    Toast.makeText(v.getContext(),"you have some element empty",Toast.LENGTH_SHORT).show();}
                else {

                    if(typ.equals("Client")) {Background b=new Background();
                    b.execute();

                            InsertPanier insertPanier = new InsertPanier();
                            insertPanier.execute();

                    }
                    else
                    {

                        Background b=new Background();
                        b.execute();
                    }
                }



            }
        });


        return v;
    }
    /*public class  BackgroundTask extends AsyncTask<String,String ,String> {
        Context context;
        BackgroundTask(Context ctx){
            this.context=ctx;
        }

        @Override
        protected String doInBackground(String... strings) {
           // String type=strings[0];
            String isadmin=strings[0];
            String lname=strings[1];
            String fname=strings[2];
            String adresse=strings[3];
            String email=strings[4];
            String phone=strings[5];
            String username=strings[6];
            String password=strings[7];
            String  regUrl="http://192.168.0.108:1880/agri/register.php";
            String exe="";
            if(type.equals("reg"))
            {
                try {
                    URL url=new URL(regUrl);
                    try{
                        HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
                        httpURLConnection.setRequestMethod("POST");
                        httpURLConnection.setDoOutput(true);
                        httpURLConnection.setDoInput(true);
                        OutputStream outputStream=httpURLConnection.getOutputStream();
                        OutputStreamWriter outputStreamWriter=new OutputStreamWriter(outputStream,"UTF-8");
                        BufferedWriter bufferedWriter=new BufferedWriter(outputStreamWriter);
                        String insert_data= URLEncoder.encode("isadmin","UTF-8")+"="+URLEncoder.encode(isadmin,"UTF-8")+"&"+URLEncoder.encode("fnClient","UTF-8")+"="+URLEncoder.encode(fname,"UTF-8")+"&"+URLEncoder.encode("lnClient","UTF-8")+"="+URLEncoder.encode(lname,"UTF-8")+"&"+URLEncoder.encode("fnClient","UTF-8")+"="+URLEncoder.encode(fname,"UTF-8")+
                                "&"+URLEncoder.encode("adresse","UTF-8")+"="+URLEncoder.encode(adresse,"UTF-8")+"&"+URLEncoder.encode("email","UTF-8")+"="+URLEncoder.encode(email,"UTF-8")+
                                "&"+URLEncoder.encode("phone","UTF-8")+"="+URLEncoder.encode(phone,"UTF-8")+"&"+URLEncoder.encode("userName","UTF-8")+"="+URLEncoder.encode(username,"UTF-8")+
                                "&"+URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8");
                        bufferedWriter.write(insert_data);
                        bufferedWriter.flush();
                        bufferedWriter.close();
                        InputStream inputStream=httpURLConnection.getInputStream();
                        InputStreamReader inputStreamReader=new InputStreamReader(inputStream,"ISO-8859-1");
                        BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
                        String result="";
                        String line="";
                        StringBuilder stringBuilder=new StringBuilder();
                        while ((line=bufferedReader.readLine())!=null)
                        {
                            stringBuilder.append(line).append("\n");
                        }
                        result=stringBuilder.toString();
                        bufferedReader.close();
                        inputStream.close();
                        httpURLConnection.disconnect();
                        return result;

                    } catch (MalformedURLException e) {
                        exe+=e.getMessage();
                    }
                }

                catch (IOException e) {
                    exe+=e.getMessage().toString();
                }

            }
            return exe;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(context,s,Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }
    }*/public class Background extends AsyncTask<Void,String ,String>
    {
        Context context;
        ProgressDialog loading;
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(getContext(), "Register do it...", "Please wait...", false, false);
        }



        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Void... strings) {
            String line="",result="";

if (type.getSelectedItem().equals("Client")) {
    try {
     String regUrl = "http://192.168.0.108:1880/agri/regeister.php?&isadmin="+0+"&lnClient="+Last_Name.getText().toString()+"&fnClient="+First_Name.getText().toString()+"&adresse="+Adresse.getText().toString()+"&email="+Email.getText().toString()+"&phone="+Phone.getText().toString()+"&userName="+Username.getText().toString()+"&password="+Password.getText().toString();
    URL url = new URL(regUrl);
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    connection.setRequestMethod("GET");
    connection.connect();
    InputStream inputStream = connection.getInputStream();
    BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
    while ((line = rd.readLine()) != null) {
        result += line;
    }
}
    catch (Exception e) {
        return e.getMessage();

    }



}
else
{
    try {
        String regUrl = "http://192.168.0.108:1880/agri/regeister.php?&isadmin="+2+"&lnClient="+Last_Name.getText().toString()+"&fnClient="+First_Name.getText().toString()+"&adresse="+Adresse.getText().toString()+"&email="+Email.getText().toString()+"&phone="+Phone.getText().toString()+"&userName="+Username.getText().toString()+"password="+Password.getText().toString();
        URL url = new URL(regUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.connect();
        InputStream inputStream = connection.getInputStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
        while ((line = rd.readLine()) != null) {
            result += line;
        }
    }
    catch (Exception e) {
        return e.getMessage();

    }




}

            return result;}

        @Override
        protected void onPostExecute(String s) {
           loading.dismiss();
            Toast.makeText(getContext(),""+s, Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }

    }
   /* public class  InsertPanier extends AsyncTask<String,String ,String> {
        Context context;
        InsertPanier(Context ctx){
            this.context=ctx;
        }

        @Override
        protected String doInBackground(String... strings) {
            String username=strings[0];



            String  regUrl="http://192.168.0.108:1880/agri/insertPanier.php";
            String exe="";

                try {
                    URL url=new URL(regUrl);
                    try{
                        HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
                        httpURLConnection.setRequestMethod("POST");
                        httpURLConnection.setDoOutput(true);
                        httpURLConnection.setDoInput(true);
                        OutputStream outputStream=httpURLConnection.getOutputStream();
                        OutputStreamWriter outputStreamWriter=new OutputStreamWriter(outputStream,"UTF-8");
                        BufferedWriter bufferedWriter=new BufferedWriter(outputStreamWriter);
                        String insert_data= URLEncoder.encode("userName","UTF-8")+"="+URLEncoder.encode(username,"UTF-8");
                        bufferedWriter.write(insert_data);
                        bufferedWriter.flush();
                        bufferedWriter.close();
                        InputStream inputStream=httpURLConnection.getInputStream();
                        InputStreamReader inputStreamReader=new InputStreamReader(inputStream,"ISO-8859-1");
                        BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
                        String result="";
                        String line="";
                        StringBuilder stringBuilder=new StringBuilder();
                        while ((line=bufferedReader.readLine())!=null)
                        {
                            stringBuilder.append(line).append("\n");
                        }
                        result=stringBuilder.toString();
                        bufferedReader.close();
                        inputStream.close();
                        httpURLConnection.disconnect();
                        return result;

                    } catch (MalformedURLException e) {
                        exe+=e.getMessage();
                    }
                }

                catch (IOException e) {
                    exe+=e.getMessage().toString();
                }


            return exe;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(context,s,Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }
    }
*/
   public class InsertPanier extends AsyncTask<Void,String ,String>
    {
        Context context;
        ProgressDialog loading;
        protected void onPreExecute() {
        super.onPreExecute();
        //loading = ProgressDialog.show(context, "Confirm your Order...", "Please wait...", false, false);
    }



        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Void... strings) {
        String line="",result="";


            try {
                String regUrl = "http://192.168.0.108:1880/agri/insertPanier.php?&userName="+Username.getText().toString();
                URL url = new URL(regUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            }
            catch (Exception e) {
                return e.getMessage();

            }




        return result;}

        @Override
        protected void onPostExecute(String s) {
        // loading.dismiss();
        Toast.makeText(getContext(),""+s, Toast.LENGTH_LONG).show();
        //super.onPostExecute(s);
    }

    }
}

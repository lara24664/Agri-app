package com.example.guidegreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class address extends Fragment {
    RecyclerView mRecyclerView;
    String username,total;
    int idpanier;
    float totalprix;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.alladressofme,container,false);
        mRecyclerView = (RecyclerView)view.findViewById(R.id.idRecyclerViewAdress);
        username=this.getArguments().getString("usernam");
        idpanier=this.getArguments().getInt("idPanier");
        totalprix=this.getArguments().getFloat("totalPrix");
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        asyncAlladress asyncAlladress=new asyncAlladress(getContext(),mRecyclerView);
        asyncAlladress.execute();
        return view;
    }
    public class AdressAdaptr extends RecyclerView.Adapter<AdressAdaptr.AdresseHolder> {
        ArrayList<String> flat,building,street,floor;
        ArrayList<String> id;
        //ArrayList<Bitmap>ima;
        Context context;

        public AdressAdaptr(ArrayList flat,ArrayList building,ArrayList street,ArrayList floor,ArrayList id, Context context) {
            this.flat = flat;
            this.building =building;
            this.street=street;
            this.floor=floor;
            this.id=id;
            //this.idadress=idadress;
            this.context = context;
        }

        @Override
        public AdresseHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            //inflate the layout file
            View groceryProductView = getLayoutInflater().inflate(R.layout.cardaddress,null);
            AdresseHolder gvh = new AdresseHolder(groceryProductView);
            return gvh;
        }
        public void onBindViewHolder(AdresseHolder holder, final int position) {
            holder.flat.setText(flat.get(position));
            holder.buildnom.setText(building.get(position));
            holder.nfloor.setText(floor.get(position));
            holder.streetname.setText(street.get(position));
            holder.idadress.setText(id.get(position));

            holder.card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    FragmentTransaction t = getFragmentManager().beginTransaction();
                    ConfirmOrder confirmOrder=new ConfirmOrder();
                    Bundle b=new Bundle();
                    b.putString("flat",flat.get(position));
                    b.putString("buildnom",building.get(position));
                    b.putString("floor",floor.get(position));
                    b.putString("street",street.get(position));
                    b.putInt("id",Integer.parseInt(id.get(position)));
                    b.putString("usern",username);
                    b.putInt("idPanier",idpanier);
                    b.putFloat("totalPrix",totalprix);
                   confirmOrder.setArguments(b);
                    t.replace(R.id.frame1,confirmOrder);
                    t.commit();
                }
            });
            //holder.txtProductQty.setText(grocderyItemList.get(position).getProductQty());


        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public int getItemCount() {
            return flat.size();
        }
        class AdresseHolder extends RecyclerView.ViewHolder {
            TextView flat,streetname,buildnom,nfloor,idadress;
            CardView card;

            // TextView txtProductQty;
            public AdresseHolder (View view) {
                super(view);
               flat=view.findViewById(R.id.hold);
                streetname=view.findViewById(R.id.streetname);
                buildnom=view.findViewById(R.id.buildinnom);
                nfloor=view.findViewById(R.id.nFloor);
                card=view.findViewById(R.id.idCardViewadress);
                idadress=view.findViewById(R.id.idadresse);

            }
        }
    }
    public class asyncAlladress extends AsyncTask<Void,String,String> {

        RecyclerView v;
        String result = "", line = "", result2 = "", line2 = "";
        BufferedReader rd;
        ArrayList<String> h,st,b,n,i;
        //List<Grocery> mProductList;
        TextView t;
        Context c;
        //Bitmap bitmap;
        ProgressDialog loading;
        AdressAdaptr g;


        asyncAlladress(Context c, RecyclerView v) {
            this.c = c;
            this.v = v;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(c, "Downloading data...", "Please wait...", false, false);
        }

        @Override
        protected String doInBackground(Void... voids) {

            try {
                String address = "http://192.168.0.108:1880/agri/selectalladress.php?name="+username;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            //Toast.makeText(getContext(),""+s,Toast.LENGTH_SHORT).show();
            // mProductList = new ArrayList<>();
            n = new ArrayList<String>();
            st = new ArrayList<String>();
            b = new ArrayList<String>();
            h=new ArrayList<String>();
            i=new ArrayList<String>();
            // Toast.makeText(getContext(), "" + s, Toast.LENGTH_SHORT).show();
            String[] z = s.split("hihi");

            for (int k = 0; k < z.length; k++) {
                // Toast.makeText(getContext(),""+z[k],Toast.LENGTH_SHORT).show();
                int d = z[k].indexOf('|');
                String sub = z[k].substring(d + 1);
                int d2 = sub.indexOf('&');
                int d3=sub.indexOf('*');
                int d4=sub.indexOf('/');
                String fla = sub.substring(0, d2);
                String nbfloor = sub.substring(d2 + 1,d3);
                String street = sub.substring(d3+1,d4);
                String build=sub.substring(d4+1);
                String id=z[k].substring(0,d);
                i.add(id);
                h.add(fla);
                b.add(build);
                n.add(nbfloor);
                st.add(street);

            }
            g=new AdressAdaptr(h,b,st,n,i,getContext());
            v.setAdapter(g);
Toast.makeText(getContext(),""+g.floor.toString()+" //// "+g.building.toString()+"---------"+g.flat.toString(),Toast.LENGTH_SHORT).show();

        }
    }
}

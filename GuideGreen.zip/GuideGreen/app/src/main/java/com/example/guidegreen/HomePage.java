package com.example.guidegreen;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HomePage extends Fragment {
    int idPanier;
    String user="";
    String id="";

    HomePage(){}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.homepage,container,false);
        user=this.getArguments().getString("username");
        idPanierget g=new idPanierget();
        g.execute();
//        idPanier=Integer.parseInt(id);
        //Toast.makeText(getContext(),""+idPanier,Toast.LENGTH_SHORT).show();
        CardView prd=v.findViewById(R.id.byu);
        CardView asmede=v.findViewById(R.id.asmide);
        CardView plantTech=v.findViewById(R.id.planting);
        CardView nurseries=v.findViewById(R.id.machtal);
        ImageView bac=v.findViewById(R.id.back);
        ImageView ab=v.findViewById(R.id.aboutus);
        ImageView pan=v.findViewById(R.id.mypanier);
        pan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                cartView view=new cartView();
                Bundle b=new Bundle();
                b.putInt("idPanier",Integer.parseInt(id));
                b.putString("user",user);
                view.setArguments(b);
                t.replace(R.id.frame1,view);
                t.addToBackStack(null);
                t.commit();

            }
        });
        bac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                loginPage l=new loginPage();
                l.e1.getText().clear();
                l.e2.getText().clear();
                transaction.replace(R.id.frame1,l);
                transaction.addToBackStack(null);
                transaction.commit();

            }
        });
        ab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
                dialog.setTitle("About us");
                dialog.setMessage("Lara kojok & Fatima Safa !");
            dialog.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                dialog.create().show();

            }
        });
        prd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                byupage b=new byupage();
                Bundle bundle=new Bundle();
                bundle.putInt("idPanier",Integer.parseInt(id));
                bundle.putString("user",user);
                b.setArguments(bundle);
                transaction.replace(R.id.frame1,b);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
        asmede.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                fragEngrais b=new fragEngrais();
                Bundle bundle=new Bundle();
                bundle.putInt("idPanier",Integer.parseInt(id));
                b.setArguments(bundle);
                transaction.replace(R.id.frame1,b);
                transaction.addToBackStack(null);
                transaction.commit();

            }
        });
        plantTech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                frglistplant b=new frglistplant();
                Bundle bundle=new Bundle();
                bundle.putInt("idPanier",Integer.parseInt(id));
                b.setArguments(bundle);
                transaction.replace(R.id.frame1,b);
                transaction.addToBackStack(null);
                transaction.commit();

            }
        });
        nurseries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                frgnurseries frgnurseries=new frgnurseries();
                Bundle bundle=new Bundle();
                bundle.putInt("idPanier",Integer.parseInt(id));
                frgnurseries.setArguments(bundle);
                transaction.replace(R.id.frame1,frgnurseries);
                transaction.addToBackStack(null);
                transaction.commit();


            }
        });

        return v;
    }
    public class idPanierget extends AsyncTask<Void,String,String>
    {
        String line="",result="";
        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/getIdPanier.php?&name="+user;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage().toString();

            }
            return result;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            id=s;
            Toast.makeText(getContext(),""+s,Toast.LENGTH_SHORT).show();
        }
    }
}

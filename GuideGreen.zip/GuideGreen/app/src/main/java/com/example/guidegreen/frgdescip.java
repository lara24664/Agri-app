package com.example.guidegreen;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class frgdescip extends Fragment {
    TextView name,good,info,size;
    LinearLayout l;
    TableRow r;
    String nom;
    frgdescip(){}
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.descrip,container,false);
        name=view.findViewById(R.id.nameEng);
        good=view.findViewById(R.id.good);
        size=view.findViewById(R.id.size);
       // info=view.findViewById(R.id.inst);
        info=view.findViewById(R.id.descrip);
        l=view.findViewById(R.id.imgBackEng);
        nom=this.getArguments().getString("name of engrais");
        name.setText(nom);
       LoadImage b = new LoadImage();
        b.execute("http://192.168.0.108:1880/agri/getImageen.php?&name="+nom);

        LoadData a = new LoadData();
        a.execute("http://192.168.0.108:1880/agri/getdescrip.php?&name="+nom);

        return view;
    }
    class LoadData extends AsyncTask<String, String, String> {
        ProgressDialog loading;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(getContext(), "Downloading data...", "Please wait...", false, false);

        }

        public String doInBackground(String... args) {
            String result = "", line = "";
            try {
                URL url = new URL(args[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                //return  e.getCause();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            loading.dismiss();
           // Toast.makeText(getContext(), "" + s, Toast.LENGTH_SHORT).show();
            String z[] = {};
            String ut[] = {};
            super.onPostExecute(s);
            loading.dismiss();
            for(int i=0;i<s.length();i++)
            {
                z=s.split("&");
            }
           // Toast.makeText(getContext(), "" + z[0], Toast.LENGTH_SHORT).show();
            good.setText(z[0]);
            size.setText(z[1]);
            info.setText(z[2]);
            //ArrayList<String> ar=new ArrayList<>();




        }
        }

        public class LoadImage extends AsyncTask<String, String, Bitmap> {
            Bitmap bitmap;

            public Bitmap doInBackground(String... args) {
                try {

                    bitmap = BitmapFactory.decodeStream((InputStream) new URL(args[0]).getContent());
                } catch (Exception e) {
                }
                return bitmap;
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {
                super.onPostExecute(bitmap);

                Drawable d = new BitmapDrawable(getResources(), bitmap);
                l.setBackground(d);
            }
        }
    }

package com.example.guidegreen;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class byupage extends Fragment {

    CardView frvg,pf,dairy,oil,mouneh;
    ImageView back,mycart;
    int id;
    String user;
    byupage(){}


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.byupage, container, false);
        id=this.getArguments().getInt("idPanier");
        user=this.getArguments().getString("user");
        Toast.makeText(getContext(),""+id,Toast.LENGTH_SHORT).show();
        frvg=v.findViewById(R.id.FruitsVegetables);
        mouneh=v.findViewById(R.id.Mouneh);
        pf=v.findViewById(R.id.PlantsFlowers);
        oil=v.findViewById(R.id.oil);
        dairy=v.findViewById(R.id.Dairies);
        mycart=v.findViewById(R.id.mycart);
        /****************************/
        frvg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                listproduct listproduct=new listproduct();
                Bundle category=new Bundle();
                category.putString("user",user);
                category.putInt("idPanier",id);
                category.putString("category","Fruits and Vegetables");
                listproduct.setArguments(category);
                t.replace(R.id.frame1,listproduct);
                t.addToBackStack(null);
                t.commit();
            }
        });


        oil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                listproduct listproduct=new listproduct();
                Bundle category=new Bundle();
                category.putString("category","Soap and Oils");
                category.putString("user",user);
                category.putInt("idPanier",id);
                listproduct.setArguments(category);
                t.replace(R.id.frame1,listproduct);
                t.addToBackStack(null);
                t.commit();
            }
        });
        mycart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              FragmentTransaction t = getFragmentManager().beginTransaction();
                cartView view=new cartView();
                Bundle b=new Bundle();
                b.putString("user",user);
                b.putInt("idPanier",id);
                view.setArguments(b);
                t.replace(R.id.frame1,view);
                t.addToBackStack(null);
                t.commit();
            }
        });


        dairy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                listproduct listproduct=new listproduct();
                Bundle category=new Bundle();
                category.putString("user",user);
                category.putInt("idPanier",id);
                category.putString("category","Dairies");
                listproduct.setArguments(category);
                t.replace(R.id.frame1,listproduct);
                t.addToBackStack(null);
                t.commit();
            }
        });




        pf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                listproduct listproduct=new listproduct();
                Bundle category=new Bundle();
                category.putString("user",user);
                category.putInt("idPanier",id);
                category.putString("category","Plant and Flowers");
                listproduct.setArguments(category);
                t.replace(R.id.frame1,listproduct);
                t.addToBackStack(null);
                t.commit();
            }
        });


        mouneh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                listproduct listproduct=new listproduct();
                Bundle category=new Bundle();
                category.putString("category","Mouneh");
                category.putInt("idPanier",id);
                category.putString("user",user);
                listproduct.setArguments(category);
                t.replace(R.id.frame1,listproduct);
                t.addToBackStack(null);
                t.commit();
            }
        });
        return v;
    }

    }


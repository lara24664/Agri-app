package com.example.guidegreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import static android.app.Activity.RESULT_OK;

public class newProduct extends Fragment {
    Spinner spinner;
    EditText t1, t2, t3, t4, t5,t6;
    Button b1, b2;
    private int PICK_IMAGE_REQUEST = 1;
    private Bitmap bitmap;
    private Uri filePath;
    public ImageView im;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.newproduct, container, false);
        spinner=v.findViewById(R.id.spinnercat);
        t1=v.findViewById(R.id.name);
        t2=v.findViewById(R.id.quantite);
        t3=v.findViewById(R.id.price);
        t4=v.findViewById(R.id.DateProduction);
        t5=v.findViewById(R.id.Dateexprition);
        t6=v.findViewById(R.id.Seller);
        b1=v.findViewById(R.id.select);
        b2=v.findViewById(R.id.addnew);
        im=v.findViewById(R.id.das_photoib);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String type = "reg";
                if (t1.getText().toString().equals("") || t2.getText().toString().equals("")
                        || t3.getText().toString().equals("") || t4.getText().toString().equals("") ||
                        t5.getText().toString().equals("")||t6.getText().toString().equals("")){
                    Toast.makeText(getContext(), "You must enter some information", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(checkdate(t4.getText().toString())&&checkdate(t5.getText().toString()))
                    {
                        BackgroundTask backgroundTask = new BackgroundTask(getContext());
                        backgroundTask.execute(type, t1.getText().toString(),
                                t2.getText().toString(), t3.getText().toString(),
                                t4.getText().toString(), t5.getText().toString(), t6.getText().toString(),
                                getStringImage(bitmap), spinner.getSelectedItem().toString());
                        //Toast.makeText(getContext(), "valid date", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getContext(), "Invalid date", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        return  v;
    }
    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }
    private boolean checkdate(String date) {
        String tb[]=date.split("-");
        if(tb.length<3)
            return false;
        else {
            int m = Integer.parseInt(tb[1]);
            int y = Integer.parseInt(tb[0]);
            int d = Integer.parseInt(tb[2]);
            if (m < 1 || m > 12)
                return false;
            else if (d < 1 || d > 31)
                return false;
            else if ((m == 4 || m == 6 || m == 9 || m == 11) && d == 31)
                return false;
            else if (m == 2) {
                boolean isleap = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0));
                if (d > 29 || (d == 29 && !isleap))
                    return false;
            }
        }
        return true;
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), filePath);
                im.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.getMessage();
            }
        }
    }
    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }
    public class  BackgroundTask extends AsyncTask<String,String ,String> {
        Context context;
        ProgressDialog loading;
        BackgroundTask(Context ctx){
            this.context=ctx;
        }

        @Override
        protected String doInBackground(String... strings) {
            String type = strings[0];
            String lname = strings[1];
            int quantite = Integer.parseInt(strings[2]);
            float price = Float.parseFloat(strings[3]);
            //String quantite=strings[2];
            // String price=strings[3];
            String dateRecolte = strings[4];
            String dateExp = strings[5];
            String seller = strings[6];
            String image = strings[7];
            String categor = strings[8];

            String regUrl = "http://192.168.0.108:1880/agri/insertProduct.php";
            String exe = "";
            if (type.equals("reg")) {
                try {
                    URL url = new URL(regUrl);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                    BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
                    String insert_data = URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(lname, "UTF-8") + "&" +
                            URLEncoder.encode("quant", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(quantite), "UTF-8") + "&" +
                            URLEncoder.encode("price", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(price), "UTF-8") + "&" +
                            URLEncoder.encode("daterec", "UTF-8") + "=" + URLEncoder.encode(dateRecolte, "UTF-8") + "&" +
                            URLEncoder.encode("dateexp", "UTF-8") + "=" + URLEncoder.encode(dateExp, "UTF-8") + "&" +
                            URLEncoder.encode("seller", "UTF-8") + "=" + URLEncoder.encode(seller, "UTF-8") + "&" +
                            URLEncoder.encode("image", "UTF-8") + "=" + URLEncoder.encode(image, "UTF-8") + "&" +
                            URLEncoder.encode("cate", "UTF-8") + "=" + URLEncoder.encode(categor, "UTF-8");
                    bufferedWriter.write(insert_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "ISO-8859-1");
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String result = "";
                    String line = "";
                    StringBuilder stringBuilder = new StringBuilder();
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    result = stringBuilder.toString();
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;
                } catch (IOException e) {
                    return e.getMessage();
                }

            }
            return "ok";
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Inserting data...", "Please wait...", false, false);
        }

        @Override
        protected void onPostExecute(String s) {
            loading.dismiss();
            Toast.makeText(context,s,Toast.LENGTH_LONG).show();
            //Snackbar.make(getView(),s,Snackbar.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }
    }
}
package com.example.guidegreen;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.snackbar.Snackbar;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class dialogFragment extends BottomSheetDialogFragment {
    TextView name,price,quantite;
    ImageView image,add,minus;
    String maxQuan;
    String nom;
    Button addtoCart;
    int idProduct;
    int idPANier;
    String user;
    String idpr;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.addtocart, container, false);
        image=v.findViewById(R.id.imamgeCart);
        name=v.findViewById(R.id.plantName);
        price=v.findViewById(R.id.price);
        quantite=v.findViewById(R.id.cart_product_quantity_tv);
        add=v.findViewById(R.id.cart_plus_img);
        minus=v.findViewById(R.id.cart_minus_img);
        addtoCart=v.findViewById(R.id.btnAddd);
         nom=this.getArguments().getString("name");
         user=this.getArguments().getString("user");
        final String pric=this.getArguments().getString("prix");
        idPANier=this.getArguments().getInt("idPanier");
        name.setText(nom);
        price.setText(pric);
        asyncmaxqu asyncmaxqu=new asyncmaxqu();
        asyncmaxqu.execute();
        getId get=new getId();
        get.execute();
//       idProduct=Integer.getInteger(idpr);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String prix=pric.split(" ")[0];
                int p=Integer.parseInt(prix);
                float qu=Float.parseFloat(quantite.getText().toString());
                if(qu<Float.parseFloat(maxQuan))
                {
                    qu+=1.0;
                    quantite.setText(String.valueOf(qu));

                    price.setText(""+p*qu+" L.B.P");
                }
                else
                {
                   add.setEnabled(true);

                }
            }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String prix=pric.split(" ")[0];
                int p=Integer.parseInt(prix);
                float qu=Float.parseFloat(quantite.getText().toString());
                if(qu>1.0)
                {
                qu-=1.0;
                quantite.setText(String.valueOf(qu));

                price.setText(""+p*qu+" L.B.P");
            }
            else
                {
                    minus.setEnabled(true);

                }}
        });
        LoadImage a = new LoadImage();
        a.execute("http://192.168.0.108:1880/agri/ProductImageSingle.php?&name="+nom);
        addtoCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BackgroundTask b = new BackgroundTask(getContext());
                b.execute();
                Snackbar.make(view, "Soil type", Snackbar.LENGTH_SHORT).show();
                Snackbar.make(view, "Saved item to Cart", Snackbar.LENGTH_LONG).setAction("Show Cart", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FragmentTransaction t = getFragmentManager().beginTransaction();
                        dialogFragment.this.dismiss();
                        Bundle bundle = new Bundle();
                        bundle.putInt("idPanier", idPANier);
                        bundle.putString("user",user);
                        cartView c = new cartView();
                        c.setArguments(bundle);
                        t.replace(R.id.frame1, c);
                        t.addToBackStack(null);
                        t.commit();
                    }
                }).show();
            }
        });
                return v;

        }
    public   class LoadImage extends AsyncTask<String, String, Bitmap> {
        Bitmap bitmap;

        public Bitmap doInBackground(String... args) {
            try {

                bitmap = BitmapFactory.decodeStream((InputStream) new URL(args[0]).getContent());
            } catch (Exception e) {
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            //  Toast.makeText(getContext(), ""+bitmap, Toast.LENGTH_SHORT).show();
            Drawable d = new BitmapDrawable(getResources(), bitmap);
            image.setImageDrawable(d);
        }
    }
    public class asyncmaxqu extends AsyncTask<Void,String,String>
    {
String line="",result="";
        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/quantite.php?&name="+nom;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {

            }
            return result;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            maxQuan=s;
        }
    }
    public class getId extends AsyncTask<Void,Void,String>{
        String result="",line="";

        @Override
        protected String doInBackground(Void... voids) {
            try {
                @SuppressLint("WrongThread") String address = "http://192.168.0.108:1880/agri/SelectIDprod.php?&name="+nom;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
           idpr=s;
            Toast.makeText(getContext(),""+s,Toast.LENGTH_SHORT).show();
        }
    }
    public class  BackgroundTask extends AsyncTask<Void,String ,String> {
        Context context;
        ProgressDialog loading;
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Add to your Cart...", "Please wait...", false, false);
        }

        BackgroundTask(Context ctx) {
            this.context = ctx;
        }


        @Override
        protected String doInBackground(Void... strings) {
            String line="",result="";
            try {
//int quant=Integer.parseInt(quantite.getText().toString());
                @SuppressLint("WrongThread") String pri=price.getText().toString().split(" ")[0];
//int p=Integer.parseInt(pri);
                @SuppressLint("WrongThread") String regUrl = "http://192.168.0.108:1880/agri/InsertComporte.php?&idProd="+Integer.parseInt(idpr)+"&idPanier="+idPANier+"&quantity="+quantite.getText().toString()+"&totalP="+pri;
                URL url = new URL(regUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }


            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            loading.dismiss();
            Toast.makeText(context, s, Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }




    }


}

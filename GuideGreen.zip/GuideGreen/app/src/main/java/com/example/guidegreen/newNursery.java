package com.example.guidegreen; import androidx.annotation.NonNull;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;


import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import static android.app.Activity.RESULT_OK;

public class newNursery extends Fragment {
    public Button b1,b2;
    TextView t1,t2,t3;
    private int PICK_IMAGE_REQUEST = 1;
    private Bitmap bitmap;
    private Uri filePath;public ImageView im;

    public newNursery(){}
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.newnursery, container, false);
        im=v.findViewById(R.id.das_photoib);
        b1=v.findViewById(R.id.select);
        b2=v.findViewById(R.id.add);
        t1=v.findViewById(R.id.adresse);
        t2=v.findViewById(R.id.location);
        t3=v.findViewById(R.id.name1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String type = "reg";
                if (t3.getText().toString().equals("") ||
                        t2.getText().toString().equals("") ||  t1.getText().toString().equals("")) {
                    Toast.makeText(getContext(), "You must enter some information", Toast.LENGTH_SHORT).show();
                } else {
                    if(checkphone(t1.getText().toString()))
                    {
                        BackgroundTask backgroundTask = new BackgroundTask(getContext());
                        backgroundTask.execute(type, t3.getText().toString(),
                                t2.getText().toString(), t1.getText().toString(), getStringImage(bitmap));
                    }
                    else
                    {
                        Toast.makeText(getContext(), "Invalid phone number", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        return v;
    }
    public void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    private boolean checkphone(String phone) {
        if(phone.length()!=8)
            return false;
        else {
            try {
                Integer.parseInt(phone);
            } catch (Exception e) {
                return false;
            }
            return true;
        }
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), filePath);
                im.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.getMessage();
            }
        }
    }
    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    public class  BackgroundTask extends AsyncTask<String,String ,String>{
        Context context;
        ProgressDialog loading;
        BackgroundTask(Context ctx){
            this.context=ctx;
        }

        @Override
        protected String doInBackground(String... strings) {
            String type = strings[0];
            String lname = strings[1];
            String location = strings[2];
            String adresse = strings[3];
            String photo = strings[4];
            String regUrl = "http://192.168.0.108:1880/agri/upload.php";
            String exe = "";
            if (type.equals("reg")) {
                try {
                    URL url = new URL(regUrl);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                    BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
                    String insert_data = URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(lname, "UTF-8") + "&"
                            + URLEncoder.encode("location", "UTF-8") + "=" + URLEncoder.encode(location, "UTF-8") +
                            "&" + URLEncoder.encode("image", "UTF-8") + "=" + URLEncoder.encode(photo, "UTF-8") + "&" +
                            URLEncoder.encode("phone", "UTF-8") + "=" + URLEncoder.encode(adresse, "UTF-8");
                    bufferedWriter.write(insert_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "ISO-8859-1");
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String result = "";
                    String line = "";
                    StringBuilder stringBuilder = new StringBuilder();
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    result = stringBuilder.toString();
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;
                } catch (Exception e) {
                    return e.getMessage();
                }

            }
            return "ok";
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Inserting data...", "Please wait...", false, false);
        }

        @Override
        protected void onPostExecute(String s) {
            loading.dismiss();
            Toast.makeText(context,s,Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }
    }

}




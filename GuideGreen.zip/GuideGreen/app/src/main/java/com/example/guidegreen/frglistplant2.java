package com.example.guidegreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.*;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
public class frglistplant2 extends Fragment {
    ListView list;
    ImageButton delete;
    ArrayList<Bitmap> imges;
    ArrayList<String> description;
    public frglistplant2() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = (View) inflater.inflate(R.layout.frglist, container, false);
        list=v.findViewById(R.id.listplant2);
        LinearLayout ly=v.findViewById(R.id.butoninsertplant);
        description=new ArrayList<>();
        Button addnew=new Button(getContext());
        addnew.setText("Add new plant");
        addnew.setTextSize(17);
        ly.addView(addnew,0);
        addnew.setWidth(500);
        addnew.setBackgroundResource(R.drawable.rounded_button);
        delete=new ImageButton(getContext());
        ly.addView(delete);
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) delete.getLayoutParams();
        params.leftMargin =350;
        delete.setBackgroundColor(0xFFFFFFF);
        delete.setImageResource(R.drawable.ic_delete_black_24dp);

       // getDescription getDescription=new getDescription(description);
       // getDescription.execute();

        getPlantImage getPlantImage=new getPlantImage();
        getPlantImage.execute();

        asyncPlant asyncPlant=new asyncPlant(getContext(),list);
        asyncPlant.execute();
        //getDescription d=new getDescription(description);
       // d.execute();



        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteplant deleteplant=new deleteplant();
                FragmentTransaction t = getFragmentManager().beginTransaction();
                t.replace(R.id.frame1, deleteplant);
                t.addToBackStack(null);
                t.commit();
            }
        });

        addnew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newPlant newPlant = new newPlant();
                FragmentTransaction t = getFragmentManager().beginTransaction();
                t.replace(R.id.frame1, newPlant);
                t.addToBackStack(null);
                t.commit();
            }
        });



        return v;
    }

    public class adptr extends BaseAdapter {
        ArrayList<String> ladptr,lord;
        public adptr(ArrayList ladptr,ArrayList lord) {
            this.ladptr = ladptr;
            this.lord=lord;
        }

        @Override
        public int getCount() {
            return ladptr.size();
            // return name.length;
        }

        @Override
        public Object getItem(int position) {
            return ladptr.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.frglistplant2, null);
            ImageView img=convertView.findViewById(R.id.img2);
            TextView txtname = convertView.findViewById(R.id.plantName2);
            TextView txtdisc=convertView.findViewById(R.id.descriptiontxt2);
            txtname.setText(ladptr.get(position));
            img.setImageBitmap(imges.get(position));
            txtdisc.setText(lord.get(position));
            return convertView;
        }
    }

    class asyncPlant extends AsyncTask<Void, String, String> {
        ListView v;
        String result = "", line = "";
        BufferedReader rd;
        ArrayList<String> l,d;
        TextView t;
        Context c;
        ProgressDialog loading;
        public asyncPlant(Context c, ListView v) {
            this.c = c;
            this.v = v;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(c,"Downloading data...","Please wait...",false,false);
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/getListPlants.php";
                //address += "?&format=json";
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                //  t.setText(e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            d=new ArrayList<String>();
            l=new ArrayList<String>();
            String[] z = s.split(".hihihi.");
            for (int k = 0; k < z.length; k++) {
                int i=z[k].indexOf("&");
                String name=z[k].substring(0,i);
                String des=z[k].substring(i+1);
                l.add(name);
                d.add(des);


            }
            adptr ad = new adptr(l,d);
            v.setAdapter(ad);
            v.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                    FragmentTransaction t = getFragmentManager().beginTransaction();
                    frgplanttech frgplanttech = new frgplanttech();
                    Bundle data=new Bundle();
                    data.putString("name of plant", l.get(position));
                    frgplanttech.setArguments(data);
                    t.replace(R.id.frame1, frgplanttech);
                    t.addToBackStack(null);
                    t.commit();
                }
            });
        }
    }
    class getPlantImage extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            String line = "", result = "";
            Bitmap BT = null;
            try {
                URL url = new URL("http://192.168.0.108:1880/agri/plantImageCount.php");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;

                }
            } catch (Exception e) {
                //return  e.getCause();
            }
            imges=new ArrayList<>();
            for(int i=0;i<=Integer.parseInt(result);i++) {
                try {
                    String x = "http://192.168.0.108:1880/agri/PlantImage.php?&idPlant="+i;
                    BT = BitmapFactory.decodeStream((InputStream)
                            new URL(x).getContent());
                    if(!BT.equals(""))
                        imges.add(BT);
                }
                catch (Exception e) {
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void v) {
            super.onPostExecute(v);
        }
    }
    class getDescription extends AsyncTask<Void, String, String> {
        String result = "", line = "";
        BufferedReader rd;
        ProgressDialog loading;
        ArrayList<String> descrp;
        public getDescription(ArrayList descrp){
            this.descrp=descrp;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // loading = ProgressDialog.show(getContext(),"Downloading data...","Please wait...",false,false);
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/getDescription.php";
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                //  t.setText(e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //  loading.dismiss();
            String[] z = s.split(".hihihi.");
            for (int k = 0; k < z.length; k++) {
                description.add(z[k]);
            }
        }
    }
}




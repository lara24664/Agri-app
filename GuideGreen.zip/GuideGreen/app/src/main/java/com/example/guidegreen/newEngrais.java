package com.example.guidegreen;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.PublicKey;

import static android.app.Activity.RESULT_OK;

public class newEngrais  extends Fragment {
    public ImageView im;
    public Button b1, b2;
    TextView t1, t2, t3, t4, t5;
    private int PICK_IMAGE_REQUEST = 1;
    private Bitmap bitmap;
    private Uri filePath;

    public newEngrais() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.newengrais, container, false);
        im = (ImageView) v.findViewById(R.id.das_photoib);
        b1 = (Button) v.findViewById(R.id.select);
        b2 = (Button) v.findViewById(R.id.add);
        t5 = (TextView) v.findViewById(R.id.nameengrais);
        //t2 = (TextView) v.findViewById(R.id.descrip);
        t1 = (TextView) v.findViewById(R.id.goodfor);
        t3 = (TextView) v.findViewById(R.id.sizeBottels);
        t4 = (TextView) v.findViewById(R.id.moreInfo);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String type = "reg";
                /*if (t1.getText().toString().equals("") || t2.getText().toString().equals("")) {
                    Toast.makeText(getContext(), "You nust enter some information", Toast.LENGTH_SHORT).show();
                } else {*/
                    BackgroundTask backgroundTask = new BackgroundTask(getContext());
                    backgroundTask.execute(type, t5.getText().toString(), t1.getText().toString(),t3.getText().toString(),getStringImage(bitmap),t4.getText().toString());
                //}
            }
        });
        return v;
    }

    public void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), filePath);
                im.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.getMessage();
            }
        }
    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    public class BackgroundTask extends AsyncTask<String, String, String> {
        Context context;

        BackgroundTask(Context ctx) {
            this.context = ctx;
        }

        @Override
        protected String doInBackground(String... strings) {
            String type = strings[0];
            String lname = strings[1];
            String good = strings[2];
            String image = strings[3];
            String  size=strings[4];
            String info=strings[5];

            String regUrl = "http://192.168.0.108:1880/agri/insertEngrais.php";
            String exe = "";
            if (type.equals("reg")) {
                try {
                    URL url = new URL(regUrl);
                    try {
                        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                        httpURLConnection.setRequestMethod("POST");
                        httpURLConnection.setDoOutput(true);
                        httpURLConnection.setDoInput(true);
                        OutputStream outputStream = httpURLConnection.getOutputStream();
                        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
                        String insert_data = URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(lname, "UTF-8")
                                + "&" + URLEncoder.encode("good_for", "UTF-8") + "=" + URLEncoder.encode(good, "UTF-8")
                                + "&" + URLEncoder.encode("image", "UTF-8") + "=" + URLEncoder.encode(image, "UTF-8")
                                + "&" + URLEncoder.encode("size", "UTF-8") + "=" + URLEncoder.encode(size, "UTF-8")
                                + "&" + URLEncoder.encode("info_uti", "UTF-8") + "=" + URLEncoder.encode(info, "UTF-8");


                        bufferedWriter.write(insert_data);
                        bufferedWriter.flush();
                        bufferedWriter.close();
                        InputStream inputStream = httpURLConnection.getInputStream();
                        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "ISO-8859-1");
                        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                        String result = "";
                        String line = "";
                        StringBuilder stringBuilder = new StringBuilder();
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        result = stringBuilder.toString();
                        bufferedReader.close();
                        inputStream.close();
                        httpURLConnection.disconnect();
                        return result;

                    } catch (MalformedURLException e) {
                        exe += e.getLocalizedMessage();
                    }
                } catch (IOException e) {
                    exe += e.getLocalizedMessage().toString();
                }

            }
            return exe;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(context, s, Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }
    }

}




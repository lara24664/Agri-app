package com.example.guidegreen;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class frgcategories extends Fragment {
    CardView frvg,pf,dairy,oil,mouneh;
    public frgcategories() {
    }

    @Nullable

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.frgcategories2, container, false);
        frvg=v.findViewById(R.id.FruitsVegetables2);
        mouneh=v.findViewById(R.id.Mouneh2);
        pf=v.findViewById(R.id.PlantsFlowers2);
        oil=v.findViewById(R.id.oil2);
        dairy=v.findViewById(R.id.Dairies2);
        /****************************/
     frvg.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               FragmentTransaction t = getFragmentManager().beginTransaction();
               listproductAdmin listproduct=new listproductAdmin();
                Bundle category=new Bundle();
             category.putString("category","Fruits and Vegetables");
              listproduct.setArguments(category);
               t.replace(R.id.frame1,listproduct);
               t.addToBackStack(null);
               t.commit();
           }
       });


       oil.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               FragmentTransaction t = getFragmentManager().beginTransaction();
               listproductAdmin listproduct=new listproductAdmin();
               Bundle category=new Bundle();
               category.putString("category","Soap and Oils");
               listproduct.setArguments(category);
               t.replace(R.id.frame1,listproduct);
               t.addToBackStack(null);
               t.commit();
           }
       });



       dairy.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               FragmentTransaction t = getFragmentManager().beginTransaction();
               listproductAdmin listproduct=new listproductAdmin();
               Bundle category=new Bundle();
               category.putString("category","Dairies");
               listproduct.setArguments(category);
               t.replace(R.id.frame1,listproduct);
               t.addToBackStack(null);
               t.commit();
           }
       });




       pf.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               FragmentTransaction t = getFragmentManager().beginTransaction();
               listproductAdmin listproduct=new listproductAdmin();
               Bundle category=new Bundle();
               category.putString("category","Plant and Flowers");
               listproduct.setArguments(category);
               t.replace(R.id.frame1,listproduct);
               t.addToBackStack(null);
               t.commit();
           }
       });


       mouneh.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               FragmentTransaction t = getFragmentManager().beginTransaction();
               listproductAdmin listproduct=new listproductAdmin();
               Bundle category=new Bundle();
               category.putString("category","Mouneh");
               listproduct.setArguments(category);
               t.replace(R.id.frame1,listproduct);
               t.addToBackStack(null);
               t.commit();
           }
       });
        return v;
    }
}

package com.example.guidegreen;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import static android.app.Activity.RESULT_OK;

public class newPlant extends Fragment {
    EditText t1, t2, t3, t4, t5, t6, t7,t8;
    Button b1, b2;
    private int PICK_IMAGE_REQUEST = 1;
    private Bitmap bitmap;
    private Uri filePath;
    public ImageView im;
    //String name,dist,sow,sun,conta,days,soils,image;

    public newPlant() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.newplant, container, false);
        t1 = v.findViewById(R.id.nameplants);
        t2 = v.findViewById(R.id.distan);
        t3 = v.findViewById(R.id.soww);
        t4 = v.findViewById(R.id.suny);
        t5 = v.findViewById(R.id.container1);
        t6 = v.findViewById(R.id.days);
        t7 = v.findViewById(R.id.Soily);
        t8=v.findViewById(R.id.descripty);
        b1 = v.findViewById(R.id.select);
        b2 = v.findViewById(R.id.add);
        im = v.findViewById(R.id.das_photoib);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            String type = "reg";
            @Override
            public void onClick(View v) {
                if (t1.getText().toString().equals("") || t2.getText().toString().equals("")
                        || t3.getText().toString().equals("") || t4.getText().toString().equals("") ||
                        t5.getText().toString().equals("")
                        || t6.getText().toString().equals("") ||  t7.getText().toString().equals("")||
                        t8.getText().toString().equals("")) {
                    Toast.makeText(getContext(), "You must enter some information", Toast.LENGTH_SHORT).show();
                } else {
                    BackgroundTask backgroundTask = new BackgroundTask(getContext());
                    backgroundTask.execute(type, t1.getText().toString(),
                            t2.getText().toString(), t3.getText().toString(),
                            t4.getText().toString(), t5.getText().toString(),
                            t6.getText().toString(), t7.getText().toString(),t8.getText().toString(),getStringImage(bitmap));
                }
            }
        });
        return v;
    }

    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), filePath);
                im.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.getMessage();
            }
        }
    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }
}
class BackgroundTask extends AsyncTask<String, String, String> {
    Context context;
    ProgressDialog loading;
    public BackgroundTask(Context ctx) {
        this.context = ctx;
    }

    @Override
    protected String doInBackground(String... strings) {
        String type = strings[0];
        String lname = strings[1];
        String dist = strings[2];
        String sow = strings[3];
        String sun = strings[4];
        String conta = strings[5];
        String days = strings[6];
        String soils = strings[7];
        String desrp = strings[8];
        String image = strings[9];

        String regUrl = "http://192.168.0.108:1880/agri/insertPlant.php";
        String exe = "";
        if (type.equals("reg")) {
            try {
                URL url = new URL(regUrl);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
                String insert_data = URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(lname, "UTF-8") + "&" +
                        URLEncoder.encode("distance", "UTF-8") + "=" + URLEncoder.encode(dist, "UTF-8") + "&" +
                        URLEncoder.encode("image", "UTF-8") + "=" + URLEncoder.encode(image, "UTF-8") + "&" +
                        URLEncoder.encode("sow", "UTF-8") + "=" + URLEncoder.encode(sow, "UTF-8") + "&" +
                        URLEncoder.encode("sun", "UTF-8") + "=" + URLEncoder.encode(sun, "UTF-8") + "&" +
                        URLEncoder.encode("container", "UTF-8") + "=" + URLEncoder.encode(conta, "UTF-8") + "&" +
                        URLEncoder.encode("day", "UTF-8") + "=" + URLEncoder.encode(days, "UTF-8") + "&" +
                        URLEncoder.encode("soil", "UTF-8") + "=" + URLEncoder.encode(soils, "UTF-8")+ "&" +
                        URLEncoder.encode("description", "UTF-8") + "=" + URLEncoder.encode(desrp, "UTF-8") ;

                bufferedWriter.write(insert_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "ISO-8859-1");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String result = "";
                String line = "";
                StringBuilder stringBuilder = new StringBuilder();
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                result = stringBuilder.toString();
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (Exception e) {
                return e.getMessage();
            }
        }
        return "ok";
    }

    @Override
    protected void onPostExecute(String s) {
        Toast.makeText(context, s, Toast.LENGTH_LONG).show();
        loading.dismiss();
        //super.onPostExecute(s);
    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        loading = ProgressDialog.show(context, "Inserting data...", "Please wait...", false, false);
    }
}

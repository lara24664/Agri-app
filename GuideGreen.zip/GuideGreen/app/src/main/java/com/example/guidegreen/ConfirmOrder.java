package com.example.guidegreen;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConfirmOrder extends Fragment{
    Button confirm,Cancel;
    ImageView addnew;
    TextView userno,idPan,TextAmount,Totalpix,flat,street,build,nbfloor;
    String user;
    int moid;
    float prix;
    EditText datee;
    int idadress;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.layoutconfirm,container,false);
        user=this.getArguments().getString("usern");
        moid=this.getArguments().getInt("idPanier");
        prix=this.getArguments().getFloat("totalPrix");
        confirm=view.findViewById(R.id.confirmation);
        Cancel=view.findViewById(R.id.canceled);
        addnew=view.findViewById(R.id.AddnewAdresse);
        userno=view.findViewById(R.id.UserNom);
        TextAmount=view.findViewById(R.id.textAmount);
        Totalpix=view.findViewById(R.id.TotalPrix);
        datee=view.findViewById(R.id.datecom);
        idPan=view.findViewById(R.id.IdPanier);
        flat=view.findViewById(R.id.FlatAdresse);
        street=view.findViewById(R.id.Street);
        build=view.findViewById(R.id.BuildingName);
        nbfloor=view.findViewById(R.id.floornb);

        userno.setText(" "+user);
        idPan.setText("  "+moid);
        TextAmount.setText(" "+prix+" L.B.P");
        Totalpix.setText(" "+prix+" L.B.P");
        street.setText(this.getArguments().getString("street"));
        flat.setText(this.getArguments().getString("flat"));
        build.setText(this.getArguments().getString("buildnom"));
        nbfloor.setText(this.getArguments().getString("floor"));
        idadress=this.getArguments().getInt("id");


        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



            }


        });
confirm.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        BackgroundTask backgroundTask=new BackgroundTask(getContext());
        backgroundTask.execute();
        updating updating=new updating(getContext());
        updating.execute();
        deletinComporte deletinComporte=new deletinComporte(getContext());
        deletinComporte.execute();
        FragmentTransaction t = getFragmentManager().beginTransaction();
        byupage listproduct=new byupage();
        Bundle category=new Bundle();
        category.putInt("idPanier",moid);
        category.putString("user",user);
        listproduct.setArguments(category);
        t.replace(R.id.frame1,listproduct);
       // t.addToBackStack(null);
        t.commit();

    }
});
addnew.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        selectData d=new selectData();
        d.execute("http://192.168.0.108:1880/agri/selectAddress.php?&name="+user);
    }
});
        return view;
    }



    public class  BackgroundTask extends AsyncTask<Void,String ,String> {
        Context context;
        ProgressDialog loading;
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Confirm your Order...", "Please wait...", false, false);
        }

        BackgroundTask(Context ctx) {
            this.context = ctx;
        }


        @Override
        protected String doInBackground(Void... strings) {
            String line="",result="";
            try {


                @SuppressLint("WrongThread") String regUrl = "http://192.168.0.108:1880/agri/addToConfirm.php?&username="+userno.getText().toString()+"&idPanier="+moid+"&Comdate="+datee.getText().toString()+"&totalP="+prix+"&idAdress="+idadress;
                URL url = new URL(regUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }


            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            loading.dismiss();
            Toast.makeText(context, s, Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }




    }

    class selectData extends AsyncTask<String,String,String>{

        @Override
        protected String doInBackground(String... strings) {
            String result="",line="";
            try {
                //String address = "http://192.168.0.113:1880/agri/deleteFromCart.php?&idProd="+idProd+"&idPan="+id;
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s.equals("having data"))
            {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                address address=new address();
                Bundle b=new Bundle();
                b.putString("usernam",user);
                b.putInt("idPanier",moid);
                b.putFloat("totalPrix",prix);
                address.setArguments(b);
                t.replace(R.id.frame1,address);
                //t.addToBackStack(null);
                t.commit();
            }
            else if(s.equals("no data"))
            {
                FragmentTransaction t = getFragmentManager().beginTransaction();
                AddAdress address=new AddAdress();
                Bundle b=new Bundle();
                b.putString("usernam",user);
                b.putInt("idPanier",moid);
                address.setArguments(b);
                t.replace(R.id.frame1,address);
               // t.addToBackStack(null);
                t.commit();
            }


            else{
                Toast.makeText(getContext(),""+s,Toast.LENGTH_SHORT).show();
            }

        }
    }

    public class  updating extends AsyncTask<Void,String ,String> {
        Context context;
        ProgressDialog loading;
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Confirm your Order...", "Please wait...", false, false);
        }

        updating(Context ctx) {
            this.context = ctx;
        }


        @Override
        protected String doInBackground(Void... strings) {
            String line="",result="";
            try {


                @SuppressLint("WrongThread") String regUrl = "http://192.168.0.108:1880/agri/updateProduct.php?&IDpAN="+moid;
                URL url = new URL(regUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }


            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            loading.dismiss();
            Toast.makeText(context, s, Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }




    }
    public class deletinComporte extends AsyncTask<Void,String ,String> {
        Context context;
        ProgressDialog loading;
        protected void onPreExecute() {
            super.onPreExecute();
            //loading = ProgressDialog.show(context, "Confirm your Order...", "Please wait...", false, false);
        }

        deletinComporte(Context ctx) {
            this.context = ctx;
        }


        @Override
        protected String doInBackground(Void... strings) {
            String line="",result="";
            try {


                @SuppressLint("WrongThread") String regUrl = "http://192.168.0.108:1880/agri/DeleteFromPanier.php?&idPan="+moid;
                URL url = new URL(regUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }


            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            // loading.dismiss();
            Toast.makeText(context, s, Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }




    }



}

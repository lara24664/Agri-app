package com.example.guidegreen;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class welcomePage extends Fragment {
    private static  int SPLASH_TIME_OUT=5000;
    public welcomePage(){}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.welcomepage,container,false);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                FragmentTransaction trans=getFragmentManager().beginTransaction();
                loginPage f=new loginPage();
                trans.add(R.id.frame1,f);
                //trans.addToBackStack(null);
                trans.commit();

            }
        },SPLASH_TIME_OUT);
        return view;
    }
}

package com.example.guidegreen;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class loginPage extends Fragment {
    TextView t1;
    EditText e1,e2;
    public loginPage(){}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.loginpage,container,false);
        t1=(TextView)view.findViewById(R.id.register);
        e1=view.findViewById(R.id.user);
        e2=view.findViewById(R.id.passLog);
        Button b=view.findViewById(R.id.login);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String us=e1.getText().toString();
                String pas=e2.getText().toString();
                if(e1.getText().equals("") || e2.getText().equals(""))
                {
                    Toast.makeText(getContext(),"some information is not enter",Toast.LENGTH_SHORT).show();
                }
                else{
                    asyncLogin a=new asyncLogin();
                    a.execute(us,pas);

            }}
        });
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction trans=getFragmentManager().beginTransaction();
                registerPage f=new registerPage();
                trans.replace(R.id.frame1,f);
                trans.addToBackStack(null);
                trans.commit();
            }
        });
        return view;
    }
    class asyncLogin extends AsyncTask<String,String,String>{
        String line="",result="";

        @Override
        protected String doInBackground(String... s) {
            String user=s[0];
            String pas=s[1];
            try {
                String address = "http://192.168.0.108:1880/agri/login.php";
                address += "?&username=" + user+"&password="+pas;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
//                Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s.equals("1"))
            {
                FragmentTransaction trans=getFragmentManager().beginTransaction();

                frgHome h=new frgHome();
                trans.replace(R.id.frame1,h);
                Bundle b=new Bundle();
                b.putString("username",e1.getText().toString());
                h.setArguments(b);
                trans.addToBackStack(null);
                trans.commit();
                Toast.makeText(getContext(), "Welcome admin.. login done", Toast.LENGTH_LONG).show();


            }
            else if (s.equals("2"))
            {
                FragmentTransaction trans=getFragmentManager().beginTransaction();
               Sellerproductview h=new Sellerproductview();
                trans.replace(R.id.frame1,h);
                Bundle b=new Bundle();
                b.putString("username",e1.getText().toString());
                h.setArguments(b);
                trans.addToBackStack(null);
                trans.commit();
                Toast.makeText(getContext(), "Welcome seller products.. login done", Toast.LENGTH_LONG).show();
            }
            else{
                FragmentTransaction trans=getFragmentManager().beginTransaction();
                HomePage h=new HomePage();
                trans.replace(R.id.frame1,h);
                Bundle b=new Bundle();
                b.putString("username",e1.getText().toString());
                h.setArguments(b);
                trans.addToBackStack(null);
                trans.commit();
                Toast.makeText(getContext(),"Welcome user.. login Done", Toast.LENGTH_LONG).show();

            }

        }
    }

}

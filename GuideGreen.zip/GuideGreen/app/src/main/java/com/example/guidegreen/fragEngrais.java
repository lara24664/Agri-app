package com.example.guidegreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class fragEngrais extends Fragment {
    ListView list;
    ArrayList<Bitmap> imges;
    public fragEngrais() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = (View) inflater.inflate(R.layout.fragentries, container, false);
        list = v.findViewById(R.id.listEngrais);
        LinearLayout ly=v.findViewById(R.id.lyFrgList);
        getPlantImage g=new getPlantImage();
        g.execute();
        asyncPlant a=new asyncPlant(getContext(),list);
        a.execute();

        return v;
}
    public class adptr extends BaseAdapter {
        ArrayList<String> ladptr;
        public adptr(ArrayList ladptr) {
            this.ladptr = ladptr;
        }

        @Override
        public int getCount() {
            return ladptr.size();
            // return name.length;
        }

        @Override
        public Object getItem(int position) {
            return ladptr.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.fargen, null);
            ImageView img=convertView.findViewById(R.id.imgagEngrais);
            TextView txtname = convertView.findViewById(R.id.engraisName);
            txtname.setText(ladptr.get(position));
            img.setImageBitmap(imges.get(position));
            return convertView;
        }
    }

    class asyncPlant extends AsyncTask<Void, String, String> {
        ListView v;
        String result = "", line = "";
        BufferedReader rd;
        ArrayList<String> l;
        TextView t;
        Context c;
        ProgressDialog loading;
        public asyncPlant(Context c, ListView v) {
            this.c = c;
            this.v = v;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(c,"Downloading data...","Please wait...",false,false);
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/getengrais.php";
                //address += "?&format=json";
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                //  t.setText(e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            l = new ArrayList<>();
            String[] z = s.split("hihihi");
            for (int k = 0; k < z.length; k++) {
                l.add(z[k]);
            }
            adptr ad = new adptr(l);
            v.setAdapter(ad);
            v.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                    FragmentTransaction t = getFragmentManager().beginTransaction();
                   frgdescip d=new frgdescip();
                    Bundle data=new Bundle();
                    data.putString("name of engrais", l.get(position));
                    d.setArguments(data);
                    t.replace(R.id.frame1, d);
                    t.addToBackStack(null);
                    t.commit();
                }
            });
        }
    }
    class getPlantImage extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            String line = "", result = "";
            Bitmap BT = null;
            try {
                URL url = new URL("http://192.168.0.108:1880/agri/CountImage.php");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;

                }
            } catch (Exception e) {
                //return  e.getCause();
            }
            imges = new ArrayList<>();
            for (int i =1; i <=Integer.parseInt(result); i++) {
                try {
                    String x = "http://192.168.0.108:1880/agri/engraisImage.php?&idEngrais=" + i;
                    BT = BitmapFactory.decodeStream((InputStream) new URL(x).getContent());
                    imges.add(BT);
                } catch (Exception e) {
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void v) {
            super.onPostExecute(v);
        }

    }

}





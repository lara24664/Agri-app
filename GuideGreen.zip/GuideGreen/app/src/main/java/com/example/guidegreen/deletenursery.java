package com.example.guidegreen;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import  android.widget.*;

import androidx.annotation.CheckResult;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearSmoothScroller;

import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class deletenursery extends Fragment {
    LinearLayout mainlayout,checkdelete,ct;
    ListView list;
    CheckBox checkall;
    ImageButton imgdelete;
    //ArrayList<Integer> postionList;
    ArrayList<String> al,checkedList;
   // int nbchecked=0;
   public deletenursery() {
    }

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = (View) inflater.inflate(R.layout.deletenursery, container, false);
        mainlayout = v.findViewById(R.id.mainlayout);
        checkdelete=v.findViewById(R.id.checkdelete);
        ct=v.findViewById(R.id.ct);
        checkall=new CheckBox(getContext());
        checkall.setText("Select all");
        //checkall.setTextColor(#8BC34A);
        checkall.setTextSize(20);
        checkdelete.addView(checkall,0);
        imgdelete=new ImageButton(v.getContext());
        checkdelete.addView(imgdelete);
        imgdelete.setImageResource(R.drawable.ic_delete_black_24dp);
        ViewGroup.MarginLayoutParams params2 = (ViewGroup.MarginLayoutParams) imgdelete.getLayoutParams();
        params2.leftMargin =600;
        imgdelete.setBackgroundColor(0xFFFFFFF);
        al=new ArrayList();
        async async=new async(getContext(),al);
        async.execute();

        checkall.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int c = 0;
                if (checkall.isChecked()) {
                    for (int i = 0; i < ct.getChildCount(); i++) {
                        final CheckBox checkItem = (CheckBox) ct.getChildAt(i);
                        checkItem.setChecked(true);
                    }
                } else {
                    for (int j = 0; j < ct.getChildCount(); j++) {
                        final CheckBox checkItem2 = (CheckBox) ct.getChildAt(j);
                        if (checkItem2.isChecked()) {
                            c++;
                        }
                    }
                    if (c >= ct.getChildCount()) {
                        for (int j = 0; j < ct.getChildCount(); j++) {
                            final CheckBox checkItem3 = (CheckBox) ct.getChildAt(j);
                            checkItem3.setChecked(false);
                        }
                    }
                }
            }
        });

        imgdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* deleteAsync deleteAsync=new deleteAsync();
                deleteAsync.execute();*/
                AlertDialog.Builder alert=new AlertDialog.Builder(getContext());
                if(checkedList.size() == 0){
                    alert.setTitle("no item selected");
                    alert.setMessage("please select item");
                    alert.setNeutralButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                }
                else if (checkedList.size()== 1) {
                    alert.setTitle("Delete this item ?\n \n \n ");
                    alert.setMessage("This item will be permanently deleted");
                    alert.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int which) {
                            deleteAsync deleteAsync=new deleteAsync();
                            deleteAsync.execute();
                            //Toast.makeText(getContext(), "successfully deleted", Toast.LENGTH_SHORT).show();
                            //Snackbar.make((View)d,"successfully deleted",Snackbar.LENGTH_SHORT).show();
                            /*s.setAction("UNDO", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    designToDelete.UndoDeleted();
                                    Snackbar.make(v, "restored!",Snackbar.LENGTH_SHORT).show();

                                }
                            });*/
                            // s.show();
                        }
                    });
                }
                else
                {
                    alert.setMessage("Delete "+checkedList.size()+" items ?\n\n \n These items will be permanently deleted");
                    alert.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            deleteAsync deleteAsync=new deleteAsync();
                            deleteAsync.execute();
                            // Toast.makeText(getContext(), "successfully deleted", Toast.LENGTH_SHORT).show();
                            //Snackbar s= Snackbar.make((View)dialog,"successfully deleted",Snackbar.LENGTH_LONG);
                            /*s.setAction("UNDO", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    designToDelete.UndoDeleted();
                                    Snackbar.make(v, "restored!",Snackbar.LENGTH_SHORT).show();

                                }
                            });*/
                            // s.show();;
                        }
                    });
                }
                alert.create().show();
            }
        });
        return v;
    }

    /*public ArrayList<String> getDeleted(){
        ArrayList<String> list=new ArrayList<>();
        for (int i = 1; i < mainlayout.getChildCount(); i++) {
            CheckBox ch = (CheckBox) mainlayout.getChildAt(i);
            if (ch.isChecked())
                list.add(ch.getText().toString());
        }
        return list;
    }*/


    public void deleteView() {
        ArrayList<View> invisibleList = new ArrayList<>();
        for (int i = 0; i < ct.getChildCount(); i++) {
            CheckBox ch = (CheckBox) ct.getChildAt(i);
            if (checkedList.contains(ch.getText())) {
                invisibleList.add(ch);
                checkedList.remove(ch.getText());
            }
        }
        for (int i = 0; i < invisibleList.size(); i++) {
            CheckBox ch = (CheckBox) invisibleList.get(i);
            ct.removeView(ch);
        }
        if(invisibleList.size()>=ct.getChildCount())
        {
            checkall.setVisibility(View.INVISIBLE);
            imgdelete.setVisibility(View.INVISIBLE);
        }
    }
    class async extends AsyncTask<Void, String, String> {
        ListView v;
        String result = "", line = "";
        ArrayList<String> n;
        TextView t;
        Context c;

        /* public async(Context c, ListView v) {
             this.c = c;
             this.v = v;
         }*/
        public  async (Context c, ArrayList n)
        {
            this.c=c;
            this.n=n;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String address = "http://192.168.0.108:1880/agri/getNurseries.php";
                address += "?&format=json";
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                //  t.setText(e.getMessage());
            }

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            n = new ArrayList<>();
            String[] z = s.split("hihi");
            for (int k = 0; k < z.length; k++) {
                int d = z[k].indexOf('&');
                String txtname = z[k].substring(0, d);
                n.add(txtname);
            }
            for(int i=0;i<n.size();i++) {
                CheckBox checkBox = new CheckBox(getContext());
                checkBox.setText(n.get(i));
                checkBox.setTextSize(24);
                ct.addView(checkBox);
                ViewGroup.MarginLayoutParams marg = (ViewGroup.MarginLayoutParams) checkBox.getLayoutParams();
                marg.topMargin =20;
            }
            checkedList=new ArrayList<>();
            for(int i=0;i<ct.getChildCount();i++)
            {
                final CheckBox checkItem=(CheckBox) ct.getChildAt(i);
                checkItem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if(checkItem.isChecked())
                            checkedList.add(checkItem.getText().toString());
                        else
                        {
                            if(!checkItem.isChecked()&&checkall.isChecked())
                            {
                                checkall.setChecked(false);
                            }
                            if(checkedList.contains(checkItem.getText()))
                            {
                                checkedList.remove(checkItem.getText());
                            }
                        }
                    }
                });
            }

            //custumAdapter ad = new custumAdapter(n);
            // v.setAdapter(ad);
        }
    }
    class deleteAsync extends  AsyncTask<Void,String,String>{

        String Dresult = "", Dline = "";

        @Override
        protected String doInBackground(Void... voids) {

               for (int i = 0; i < checkedList.size(); i++) {
                String address = "http://192.168.0.108:1880/agri/deleteNursery.php?name="+checkedList.get(i);
                try {
                   // address += "?&format=json";
                    URL url = new URL(address);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                    while ((Dline = rd.readLine()) != null) {
                        Dresult += Dline;
                    }
                } catch (Exception e) {
                    return e.getMessage();
                }
            }
            return Dresult;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s.contains("Delete Successfully")) {
                Toast.makeText(getContext(), "Delete successfully", Toast.LENGTH_SHORT).show();
                deleteView();
            }
            else
                Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
            //  Snackbar.make(v,s,Snackbar.LENGTH_LONG).show();
            //else
            //   Snackbar.make(v,s,Snackbar.LENGTH_LONG).show();*/
        }
    }
}

package com.example.guidegreen;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import android.widget.*;

import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class frgplanttech2 extends Fragment {
    CardView fullsun,sowDepth,containerDepth,distance,soiltype,days;
    TextView txtplantName;
    LinearLayout l;
    TextView sd,cd,fl,db,day,st;
    public frgplanttech2() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.frglistplant, container, false);
       fullsun=v.findViewById(R.id.fullSun2);
        distance=v.findViewById(R.id.distance2);
        sowDepth=v.findViewById(R.id.sowDepth2);
        containerDepth=v.findViewById(R.id.containerDepth2);
        days=v.findViewById(R.id.days2);
        soiltype=v.findViewById(R.id.soilType2);
        /********************************************/
        st=v.findViewById(R.id.st2);
        fl=v.findViewById(R.id.fl2);
        cd=v.findViewById(R.id.cd2);
        day=v.findViewById(R.id.day2);
        db=v.findViewById(R.id.db2);
        sd=v.findViewById(R.id.sd2);
       /******************************************/
        txtplantName=v.findViewById(R.id.plantName2);
        l=v.findViewById(R.id.imgBack);


     String plantName= this.getArguments().getString("name of plant");
      txtplantName.setText(plantName);

        LoadImage a = new LoadImage();
        a.execute("http://192.168.0.108:1880/agri/PlantTechLoadImage.php?&name="+plantName);

        LoadData b = new LoadData();
        b.execute("http://192.168.0.108:1880/agri/getPlantTech.php?&name="+plantName);


        fullsun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(getContext(), "Loves sunny, warm spots", Toast.LENGTH_SHORT).show();
                Snackbar.make(v,"Loves sunny, warm spots",Snackbar.LENGTH_SHORT).show();
            }
        });

        days.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(getContext(), "Average amount of days before harvest", Toast.LENGTH_SHORT).show();
                Snackbar.make(v,"Average amount of days before harvest",Snackbar.LENGTH_SHORT).show();
            }
        });

        soiltype.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getContext(), "Soil type", Toast.LENGTH_SHORT).show();
                Snackbar.make(v,"Soil type",Snackbar.LENGTH_SHORT).show();
            }
        });


        containerDepth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getContext(), "Container depth", Toast.LENGTH_SHORT).show();
                Snackbar.make(v,"Container depth",Snackbar.LENGTH_SHORT).show();
            }
        });


        sowDepth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(getContext(), "Sow depth", Toast.LENGTH_SHORT).show();
                Snackbar.make(v,"Sow depth",Snackbar.LENGTH_SHORT).show();
            }
        });

        distance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getContext(), "Distance between plants", Toast.LENGTH_SHORT).show();
                Snackbar.make(v,"Distance between plants",Snackbar.LENGTH_SHORT).show();
            }
        });
        return v;
    }


    public   class LoadImage extends AsyncTask<String, String, Bitmap> {
        Bitmap bitmap;

        public Bitmap doInBackground(String... args) {
            try {

                bitmap = BitmapFactory.decodeStream((InputStream) new URL(args[0]).getContent());
            } catch (Exception e) {
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            //  Toast.makeText(getContext(), ""+bitmap, Toast.LENGTH_SHORT).show();
            Drawable d = new BitmapDrawable(getResources(), bitmap);
            l.setBackground(d);
        }
    }
    class LoadData extends AsyncTask<String, String, String> {
        ProgressDialog loading;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(getContext(),"Downloading data...","Please wait...",false,false);

        }

        public String doInBackground(String... args) {
            String result="",line="" ;
            try {
                URL url = new URL(args[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                //return  e.getCause();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            String z[]={};
            super.onPostExecute(s);
            loading.dismiss();
            for(int i=0;i<s.length();i++)
            {
                z=s.split("&");
            }
            sd.setText(z[0]); db.setText(z[1]); fl.setText(z[2]); st.setText(z[3]);
            cd.setText(z[4]); day.setText(z[5]);
        }
    }


}

package com.example.guidegreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class listproductAdmin extends Fragment {
    private RecyclerView mRecyclerView;
    private GroceryProductAdapter g;
    LinearLayout addel;
    int countheart;
    ArrayList<Bitmap> images;
    ImageButton delete;
    String user;
    TextView t;
   // private ArrayList<Grocery> ProductList;

    String cat;
    Button addnew;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = (View) inflater.inflate(R.layout.listproduct2, container, false);
        mRecyclerView = (RecyclerView)v.findViewById(R.id.idRecyclerView2);
        addel=v.findViewById(R.id.adddelete);
        cat=this.getArguments().getString("category");
        //user=this.getArguments().getString("user");
        t=v.findViewById(R.id.Cat2);
        addnew=v.findViewById(R.id.newProduct);
        t.setText(cat);
        delete=new ImageButton(getContext());
        addel.addView(delete);
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) delete.getLayoutParams();
        params.leftMargin =350;
        delete.setBackgroundColor(0xFFFFFFF);
        delete.setImageResource(R.drawable.ic_delete_black_24dp);
        //mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        getPlantImage g=new getPlantImage();
        g.execute();
        asyncProducts a=new asyncProducts(getContext(),mRecyclerView);
        a.execute();

       /* mProductList = new ArrayList<>();
        mProductList.add(new Grocery("Mango",R.drawable.appels,"Rs. 150", "1 kg"));
        mProductList.add(new Grocery("Pineapple",R.drawable.appels,"Rs. 250", "500 gm"));*/

        //set adapter to recyclerview

addnew.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        newProduct newProduct=new newProduct();
        FragmentTransaction t = getFragmentManager().beginTransaction();
        t.replace(R.id.frame1, newProduct);
        t.addToBackStack(null);
        t.commit();
    }
});
delete.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        FragmentTransaction t = getFragmentManager().beginTransaction();
        deleteproduct deleteplant=new deleteproduct();
        Bundle b=new Bundle();
        b.putString("category",cat);
        deleteplant.setArguments(b);
        t.replace(R.id.frame1, deleteplant);
        t.addToBackStack(null);
        t.commit();
    }
});
        return v;
    }

      public class GroceryProductAdapter extends RecyclerView.Adapter<GroceryProductAdapter.GroceryProductViewHolder> {
        ArrayList<String> name,price,quantitty;
        //ArrayList<Bitmap>ima;
        Context context;

        public GroceryProductAdapter(ArrayList name,ArrayList price,ArrayList quantitty, Context context) {
            this.name = name;
            this.price=price;
            this.quantitty=quantitty;
           // this.ima=ima;
            this.context = context;
        }

        @Override
        public GroceryProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            //inflate the layout file
            View groceryProductView = getLayoutInflater().inflate(R.layout.cardviewproduct2,null);
            GroceryProductViewHolder gvh = new GroceryProductViewHolder(groceryProductView);
            return gvh;
        }

        @Override
        public void onBindViewHolder(GroceryProductViewHolder holder, final int position) {
             holder.imageProductImage.setImageBitmap(images.get(position));
             holder.txtProductName.setText(name.get(position));
             holder.txtProductPrice.setText(price.get(position));
             holder.txtProductWeight.setText(quantitty.get(position));
            //holder.txtProductQty.setText(grocderyItemList.get(position).getProductQty());

            holder.imageProductImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String productName = name.get(position);
                    Toast.makeText(context, productName + " is selected", Toast.LENGTH_SHORT).show();
                }
            });
            holder.like.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (countheart == 0) {
                        countheart = 1;
                        ((ImageView)v).setImageResource(R.drawable.like);
                        Toast.makeText(getContext(),""+name.get(position)+" Liked",Toast.LENGTH_SHORT).show();
                    } else {
                        countheart = 0;
                        ((ImageView)v).setImageResource(R.drawable.unlike);
                        Toast.makeText(getContext(),""+name.get(position)+" UnLiked",Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public int getItemCount() {
            return name.size();
        }
        class GroceryProductViewHolder extends RecyclerView.ViewHolder {
            ImageView imageProductImage,like,addto;
            TextView txtProductName;
            TextView txtProductPrice;
            TextView txtProductWeight;

            // TextView txtProductQty;
            public GroceryProductViewHolder(View view) {
                super(view);
               imageProductImage = view.findViewById(R.id.idProductImage2);
                txtProductName = view.findViewById(R.id.idProductName2);
                txtProductPrice = view.findViewById(R.id.idProductPrice2);
                txtProductWeight = view.findViewById(R.id.idProductWeight2);
                like=view.findViewById(R.id.idMinusICon2);
               // addto=view.findViewById(R.id.idPlusIcon2);
                //  txtProductQty = view.findViewById(R.id.idProductQty);
            }
        }
    }
    public class asyncProducts extends AsyncTask<Void,String,String> {

        RecyclerView v;
        String result = "", line = "", result2 = "", line2 = "";
        BufferedReader rd;
        ArrayList<String> p, n, l;
        //List<Grocery> mProductList;
        TextView t;
        Context c;
        //Bitmap bitmap;
        ProgressDialog loading;
        ArrayList<Bitmap> images;
        //AlertDialog.Builder dialog;
        //ImageButton delete;

        asyncProducts(Context c, RecyclerView v) {
            this.c = c;
            this.v = v;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(c, "Downloading data...", "Please wait...", false, false);
        }

        @Override
        protected String doInBackground(Void... voids) {

            try {
                String address = "http://192.168.0.108:1880/agri/getAll.php?&name="+cat;
                URL url = new URL(address);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            //Toast.makeText(getContext(),""+s,Toast.LENGTH_SHORT).show();
           // mProductList = new ArrayList<>();
            n = new ArrayList<String>();
            p = new ArrayList<String>();
            l = new ArrayList<String>();
           // Toast.makeText(getContext(), "" + s, Toast.LENGTH_SHORT).show();
            String[] z = s.split("%fi%");

            for (int k = 0; k < z.length; k++) {
               // Toast.makeText(getContext(),""+z[k],Toast.LENGTH_SHORT).show();
                int d = z[k].indexOf('.');
                String sub = z[k].substring(d + 1);
                int d2 = sub.indexOf('<');
                String price = sub.substring(0, d2)+" L.B.P";
                String quantity = sub.substring(d2 + 1);
                String txtname = z[k].substring(0, d);
                n.add(txtname);
                p.add(price);
                l.add(quantity);

            }
            ArrayList<String> lll=new ArrayList<>();
            for (int j=0;j<n.size();j++) {
             lll.add(n.get(j));
            }
             g=new GroceryProductAdapter(n,p,l,getContext());
            v.setAdapter(g);
//Toast.makeText(getContext(),""+g.price.toString()+" //// "+g.name.toString()+"---------"+g.quantitty.toString(),Toast.LENGTH_SHORT).show();

        }
    }
    class getPlantImage extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            String line = "", result = "";
            Bitmap BT = null;
            try {
                URL url = new URL("http://192.168.0.108:1880/agri/productImageCount.php?&categorie="+cat);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;

                }
            } catch (Exception e) {
                //return  e.getCause();
            }
            images=new ArrayList<>();
            for(int i=1;i<=Integer.parseInt(result);i++) {
                try {
                    String x = "http://192.168.0.108:1880/agri/ProductImage.php?&categorie="+cat+"&idpro="+i;
                    BT = BitmapFactory.decodeStream((InputStream)
                            new URL(x).getContent());
                    if(!BT.equals(""))
                        images.add(BT);
                } catch (Exception e) {
                   // Toast.makeText(getContext(),""+e.getMessage(),Toast.LENGTH_SHORT).show();
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void v) {
            super.onPostExecute(v);
           // Toast.makeText(getContext(),""+images.get(),Toast.LENGTH_SHORT).show();
        }
    }
}


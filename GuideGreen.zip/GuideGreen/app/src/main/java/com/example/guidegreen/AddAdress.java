package com.example.guidegreen;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class AddAdress extends Fragment {
    EditText flat,street,building,nbfloor;
    Button save;
    String username;
    @Nullable
    int idpan;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.addadresse,container,false);
        flat=view.findViewById(R.id.addflatadresse);
        street=view.findViewById(R.id.addStreetName);
        building=view.findViewById(R.id.addBuidingName);
        nbfloor=view.findViewById(R.id.nbfloor);
        save=view.findViewById(R.id.saveadresse);
        username=this.getArguments().getString("usernam");
        idpan=this.getArguments().getInt("idPanier");

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAdresse a=new addAdresse();
                a.execute();
                Bundle b=new Bundle();
                b.putString("usernam",username);
                b.putInt("idPanier",idpan);
                ConfirmOrder c=new ConfirmOrder();
                c.setArguments(b);

            }
        });
        return view;
    }
    public class  addAdresse extends AsyncTask<Void,String ,String> {
        Context context;
        ProgressDialog loading;
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(getContext(), "Confirm your Order...", "Please wait...", false, false);
        }



        @Override
        protected String doInBackground(Void... strings) {
            String line="",result="";
            try {


                @SuppressLint("WrongThread") String regUrl = "http://192.168.0.108:1880/agri/addnewadresse.php?&username="+username+"&flat="+flat.getText().toString()+"&floor="+Integer.parseInt(nbfloor.getText().toString())+"&street="+street.getText().toString()+"&building="+building.getText().toString();
                URL url = new URL(regUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();

            }


            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            loading.dismiss();
            Toast.makeText(getContext(),""+s, Toast.LENGTH_LONG).show();
            //super.onPostExecute(s);
        }




    }

}

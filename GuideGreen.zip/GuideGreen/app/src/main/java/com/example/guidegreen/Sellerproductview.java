package com.example.guidegreen;

import androidx.fragment.app.Fragment;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.widget.ListViewCompat;
import androidx.fragment.app.Fragment;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;



public class Sellerproductview extends Fragment {
    ArrayList<String> nameOfPrdct, nbOfBuy;
    ListView listView;
    ArrayAdapter<String> adapter;
    String z[] = {};
    AlertDialog.Builder alert;
    String userna;

    public Sellerproductview() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // return super.onCreateView(inflater, container, savedInstanceState);
        View v = (View) inflater.inflate(R.layout.sellerproductview, container, false);
        TextView t=v.findViewById(R.id.userSeller);
        userna=this.getArguments().getString("username");
        //maingrd = v.findViewById(R.id.mainGrid);
        listView=v.findViewById(R.id.listView);
        t.setText(""+userna);


        LoadData loadData=new LoadData();
        loadData.execute("http://192.168.0.108:1880/agri/getSellerProduct.php?&sellerName="+userna);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                alert=new AlertDialog.Builder(getContext());
                alert.setTitle(nameOfPrdct.get(position));
                alert.setMessage("number of buy: "+nbOfBuy.get(position));
                alert.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alert.create().show();
            }
        });
        return v;
    }

    class LoadData extends AsyncTask<String, String, String> {
        ProgressDialog loading;
        public   LoadData (){

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(getContext(), "Downloading data...", "Please wait...", false, false);

        }

        public String doInBackground(String... args) {
            String result = "", line = "";
            try {
                URL url = new URL(args[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                while ((line = rd.readLine()) != null) {
                    result += line;
                }
            } catch (Exception e) {
                return e.getMessage();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            nameOfPrdct = new ArrayList<>();
            nbOfBuy = new ArrayList<>();
            for (int i = 0; i < s.length(); i++) {
                z = s.split(">");
            }
            for (int i = 0; i < z.length; i++) {
                String k[] = {};
                k = z[i].split("<");
                nbOfBuy.add(k[1]);
                nameOfPrdct.add(k[0]);
            }
            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, nameOfPrdct);
            listView.setAdapter(adapter);
        }
    }


}

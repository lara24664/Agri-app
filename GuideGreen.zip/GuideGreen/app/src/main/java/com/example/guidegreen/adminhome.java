package com.example.guidegreen;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class adminhome extends Fragment {

    adminhome(){}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.adminhome,container,false);
        CardView prd=v.findViewById(R.id.byu);
        CardView asmede=v.findViewById(R.id.asmide);
        CardView plantTech=v.findViewById(R.id.planting);
        CardView nurseries=v.findViewById(R.id.machtal);
        prd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                byupage b=new byupage();
                transaction.replace(R.id.frame1,b);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
        asmede.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        plantTech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        nurseries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                frgnurseries frgnurseries=new frgnurseries();
                transaction.replace(R.id.frame1,frgnurseries);
                transaction.addToBackStack(null);
                transaction.commit();


            }
        });

        return v;
    }
    public void backlis(View v)
    {
        FragmentTransaction transaction=getFragmentManager().beginTransaction();
        loginPage l=new loginPage();
        transaction.replace(R.id.frame1,l);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}

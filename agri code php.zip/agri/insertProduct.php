<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
   // echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='POST'){
   $sql ="SELECT idProduct FROM product ORDER BY idProduct ASC";
		
		$res = mysqli_query($con,$sql);
		
		$id = 0;
		
		while($row = mysqli_fetch_array($res)){
				$id = $row['idProduct'];
		}
 $name = $_POST['name'];
 $quantite = $_POST['quant'];
 $price =$_POST['price'];
 $daterec =$_POST['daterec'];
 $dateexp =$_POST['dateexp'];
  $seller =$_POST['seller'];
 $categorie =$_POST['cate'];
 
$image = $_POST['image'];
 $buffer=base64_decode($image);
	$buffer=$con->real_escape_string($buffer);
//$path = "product/$id.jpeg";
//$actualpath = "http://localhost/finalproject308/$path";
$query = "INSERT INTO `product`(`name`, `quantity`, `price`, `dateRecolte`, `DateExpiration`,`sellerUserName`, `photo`, `Categorie`) VALUES ('$name','$quantite','$price','$daterec','$dateexp','$seller','$buffer','$categorie')";
    if(mysqli_query($con,$query))
    {
        //file_put_contents($path,base64_decode($image));
        echo "Inserted successfully";
    }
    else{
        echo mysqli_error($con);
    }
}
else{
    echo "error in request method";
}

?>
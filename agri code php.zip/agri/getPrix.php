<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
        $name=$_GET['name'];
		$query_search = "SELECT * FROM `product` WHERE
    `Categorie`='$name'";
		$result = @mysqli_query($dbc, $query_search);
        echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			$data=array();
			while($row=mysqli_fetch_array($result))
			{
				//$data[]=$row;
				echo $row['price']."end";
			}
		//print (json_encode(array("nurseries"=>$data)));
		//"<".$row['location'].
		}
	else echo "error"; 
@mysqli_close($dbc);
	}
}
?>
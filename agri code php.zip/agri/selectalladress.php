<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
        $name=$_GET['name'];
		$query_search = "SELECT `idAdresse`, `flatAdresse`, `floor_no`, `Street`, `urlGoogleMap`, `BuildingName` FROM `adressede` WHERE
    `Username`='$name'";
		$result = @mysqli_query($dbc, $query_search);
        echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			while($row=mysqli_fetch_array($result))
			{
				//$data[]=$row;
				echo $row['idAdresse']."|".$row['flatAdresse']."&".$row['floor_no']."*".$row['Street']."/".$row['BuildingName']."hihi";
			}
		}
        
    }
   
	 
@mysqli_close($dbc);
	}

?>
<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='GET'){
 
 $user_Name =$_GET['userName'];   
 
$query = "INSERT INTO `panier`(`userName`) VALUES ('$user_Name')";
    if(mysqli_query($con,$query))
    {
        echo"add panier successfully";
    }
    else{
        echo"error in addPanier";
    }
}
else{
    echo"error in request method";
}

?>
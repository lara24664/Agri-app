<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
        $name=$_GET['name'];
		$query_search = "SELECT * FROM `adressede` WHERE
    `Username`='$name'";
		$result = @mysqli_query($dbc, $query_search);
        echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			echo"having data";
		}
        else
        {
            echo"no data";
        }
    }
    else{echo"error connection";}
	 
@mysqli_close($dbc);
	}

?>
<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    //echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='GET'){
 
 $user = $_GET['username'];
 $idPanier = $_GET['idPanier'];
 $date =$_GET['Comdate'];
 $totalPric =$_GET['totalP'];
$idAdr=$_GET['idAdress'];
$query = "INSERT INTO `commande`(`userName`, `idPanier`, `datee`, `libelle`, `idAdresse`) VALUES('$user','$idPanier','$date','$totalPric','$idAdr')";
    if(mysqli_query($con,$query))
    {
        echo"Commande successfully";
    }
    else{
        echo"error in registration";
    }
}
else{
    echo"error in request method";
}

?>
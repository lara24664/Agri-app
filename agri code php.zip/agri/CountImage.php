<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$query_search = "select Max(idEngrais) from engra";
	$res = @mysqli_query($dbc, $query_search);
	
		if(@mysqli_num_rows($res) > 0)
		{

$result = array();
	
	while($row = mysqli_fetch_array($res)){

		echo $row['Max(idEngrais)'];
	}
		
		}
mysqli_close($dbc);

	}
}
?>
<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
       $categorie=$_GET['categorie'];
		$query_search = "select Max(idProduct) from product where Categorie='$categorie'";
	$res = @mysqli_query($dbc, $query_search);
	
		if(@mysqli_num_rows($res) > 0)
		{

$result = array();
	
	while($row = mysqli_fetch_array($res)){

		echo $row['Max(idProduct)'];
	}
		
		}
mysqli_close($dbc);

	}
}
?>
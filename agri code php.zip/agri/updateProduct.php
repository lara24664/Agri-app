<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    echo"connection success";
        $pan=$_GET['IDpAN'];
		$query_search = "SELECT * FROM `comporte` WHERE `idPanier`='$pan'";
		$result = mysqli_query($con, $query_search);
		if(mysqli_num_rows($result) > 0)
		{
            echo"select go";
			$data=array();
			while($row=mysqli_fetch_array($result))
			{
                
				//$data[]=$row;
                $var=(int)$row['quantity2'];
                $query = "UPDATE product SET quantity= (quantity-$var), nbOfBuy= (nbOfBuy+$var) WHERE idProduct='".$row['idProduct']."' ";
				 if(mysqli_query($con,$query))
                 {echo"update success";}
                else{echo mysqli_error($con);}
			}
		//print (json_encode(array("nurseries"=>$data)));
		//"<".$row['location'].
		}
    else
    {
        echo"error in select";
    }
@mysqli_close($dbc);
}
else{
    echo"connection failed ";
}

?>
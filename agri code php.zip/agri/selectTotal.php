<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$id=$_GET['idPan'];
		$query_search = "select TotalPrice from comporte where idPanier='$id'";
	$result = @mysqli_query($dbc, $query_search);

		if(@mysqli_num_rows($result) > 0)
		{
			$rows = array();
while($row = mysqli_fetch_array($result)) {
echo $row['TotalPrice']."end";

}
mysqli_close($dbc);

}
else
	 echo "0 end";
	}
}
?>
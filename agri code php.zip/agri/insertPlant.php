<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
   // echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='POST'){
   
 $L_name = $_POST['name'];
 $dis = $_POST['distance'];
 $sow =$_POST['sow'];
$sun =$_POST['sun'];
    $container =$_POST['container'];
    $days =$_POST['day'];
 $soil =$_POST['soil'];
 $description =$_POST['description'];
      $image = $_POST['image'];
	  $buffer=base64_decode($image);
	$buffer=$con->real_escape_string($buffer);
//$path = "plant/$id.jpeg";
//$actualpath = "http://localhost/finalproject308/$path";
$query = "INSERT INTO `plant`(`name`, `distance_between_plant`,`photo`, `sow_depth`, `full_sun`, `container_depth`, `days_before_harvest`, `soil_type`,
`description`) VALUES ('$L_name','$dis','$buffer','$sow','$sun','$container','$days','$soil','$description')";
    if(mysqli_query($con,$query))
    {
        //file_put_contents($path,base64_decode($image));
        echo "Inserted successfully";
    }
    else{
        echo mysqli_error($con);
    }
}
else{
    echo "error in request method";
}

?>
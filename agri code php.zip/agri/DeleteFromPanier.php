<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
    {
        $pan=$_GET['idPan'];
		$query_search = "SELECT * FROM `comporte` c WHERE c.idPanier='$pan'";
		$result = @mysqli_query($dbc, $query_search);
        echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			$data=array();
			while($row=mysqli_fetch_array($result))
			{
                echo $row['idPanier'];
				$query = "delete from comporte where idProduct='{$row['idProduct']}'&& idPanier='{$row['idPanier']}'";
			if(@mysqli_query($dbc, $query))
			{
				echo "Delete Successfully";
			}
                else echo "Delete Failed";
			
		}
		
			}
		//print (json_encode(array("nurseries"=>$data)));
		//"<".$row['location'].
		}
        
    }

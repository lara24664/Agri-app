<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$name=$_GET['name'];
		$query_search = "select `distance_between_plant`, `sow_depth`, `full_sun`, `container_depth`, `days_before_harvest`, `soil_type`from plant where name='$name'";
	$result = @mysqli_query($dbc, $query_search);
			//echo "ok";
		
		//	echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			//$rows = array();

// iterate to query result and add every rows into array
while($row = mysqli_fetch_array($result)) {
//$rows[]=$row;
echo $row['sow_depth']."&".$row['distance_between_plant']."&".$row['full_sun']."&". 
$row['soil_type']."&".$row['container_depth']."&".$row['days_before_harvest'];

}

// close the database connection
mysqli_close($dbc);

// echo the application data in json format
//echo json_encode($rows);
}
	}
}
?>
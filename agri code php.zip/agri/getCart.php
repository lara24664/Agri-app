<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
        $pan=$_GET['idPan'];
		$query_search = "SELECT * FROM `comporte` AS c INNER JOIN `product` AS p ON c.idProduct = p.idProduct WHERE c.idPanier='$pan'";
		$result = @mysqli_query($dbc, $query_search);
        echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			$data=array();
			while($row=mysqli_fetch_array($result))
			{
				echo $row['name']."+".$row['TotalPrice']."<".$row['quantity2']."%fi%";
			}
		//print (json_encode(array("nurseries"=>$data)));
		//"<".$row['location'].
		}
	else echo "error"; 
@mysqli_close($dbc);
	}
}
?>

<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='GET'){
 $isadmin = $_GET['isadmin'];
 $L_name=$_GET['lnClient'];
 $F_name=$_GET['fnClient'];
 $Adresse=$_GET['adresse'];
 $email=$_GET['email'];
 $phone=$_GET['phone'];
 $user_Name=$_GET['userName'];   
 $password=$_GET['password'];
$query = "INSERT INTO `client`(`isAdmin`, `lnClient`, `fnClient`, `adresse`, `email`, `phone`, `userName`, `password`) VALUES ('$isadmin','$L_name','$F_name','$Adresse','$email','$phone','$user_Name','$password')";
    
    if(mysqli_query($con,$query))
    {
        echo"Regeister successfully";
    }
    else{
        echo"error in Register";
    }
}


?>
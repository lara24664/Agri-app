<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='POST'){
   
		
 
 $L_name = $_POST['name'];
 $image = $_POST['image'];
    $good=$_POST['good_for'];
 $size=$_POST['size'];
    $info=$_POST['info_uti'];
 $buffer=base64_decode($image);
	$buffer=$con->real_escape_string($buffer);

 
$query = "INSERT INTO `engra`(`name`, `good_for`, `photo`, `size`, `info_uti`) VALUES ('$L_name','$good','$buffer','$size','$info')";
    if(mysqli_query($con,$query))
    {
       // file_put_contents($path,base64_decode($image));
        echo "<br>"."Inserted successfully";
    }
    else{
      echo "<br>".mysqli_error($con);
    }
}
else{
    echo "<br>"."error in request method";
}

?>
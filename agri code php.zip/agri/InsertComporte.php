<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    //echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='GET'){
 
 $idProd = $_GET['idProd'];
 $idPanier = $_GET['idPanier'];
 $quantity =$_GET['quantity'];
 $totalPric =$_GET['totalP'];
$query = "INSERT INTO `comporte`(`idProduct`, `idPanier`, `quantity2`, `TotalPrice`) VALUES ('$idProd','$idPanier','$quantity','$totalPric')";
    if(mysqli_query($con,$query))
    {
        echo"Add to cart successfully";
    }
    else{
        echo"error in registration";
    }
}
else{
    echo"error in request method";
}

?>
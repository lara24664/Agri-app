<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    //echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='GET'){
 
 $user = $_GET['username'];
 $flat= $_GET['flat'];
 $floor =$_GET['floor'];
 $street =$_GET['street'];
$building=$_GET['building'];
$query = "INSERT INTO `adressede`( `Username`, `flatAdresse`, `floor_no`, `Street`,`BuildingName`) VALUES ('$user','$flat','$floor','$street','$building')";
    if(mysqli_query($con,$query))
    {
        echo"add address successfully";
    }
    else{
        echo"error in registration";
    }
}
else{
    echo"error in request method";
}

?>
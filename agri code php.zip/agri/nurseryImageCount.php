<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$query_search = "select Max(idNursery) from nurseries";// where idNursery=21";
	$res = @mysqli_query($dbc, $query_search);
			//echo "ok";
	//else
		
		//echo mysqli_error($dbc);
		if(@mysqli_num_rows($res) > 0)
		{
			//$rows = array();

// iterate to query result and add every rows into array
/*while($row = mysqli_fetch_array($result)) {
//$rows[]=$row;
//echo $row['photo']."end";

}*/
$result = array();
	
	while($row = mysqli_fetch_array($res)){
		//$base=base64_decode($row['photo']);
		//array_push($result,array('url'=>$row['photo']));
		echo $row['Max(idNursery)'];
	}
		
	//echo json_encode(array("result"=>$result));
		}
// close the database connection
mysqli_close($dbc);

// echo the application data in json format
//echo json_encode($rows);
	}
}
?>
<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
   // echo"connection success";
    
}
else{
    echo"connection failed ";
}
if($_SERVER['REQUEST_METHOD']=='POST'){
 $sql ="SELECT idNursery FROM nurseries ORDER BY idNursery ASC";
		
		$res = mysqli_query($con,$sql);
		
		$id = 0;
		
		while($row = mysqli_fetch_array($res)){
				$id = $row['idNursery'];
		}
		
 $L_name = $_POST['name'];
 $F_name = $_POST['location'];
 $phone =$_POST['phone'];
$image = $_POST['image'];
  $buffer=base64_decode($image);
	$buffer=$con->real_escape_string($buffer);
//$path = "nursery/$id.jpeg";
//$actualpath = "http://localhost/finalproject308/$path";
$query = "INSERT INTO `nurseries`(`name`,`location`,`photo`,`phone`) VALUES ('$L_name','$F_name','$buffer','$phone')";
    if(mysqli_query($con,$query))
    {
     // file_put_contents($path,base64_decode($image));
        echo "Inserted successfully";
    }
    else{
   
		echo mysqli_error($con);
    }
}
else{
    echo  "<br>"."error in request method";
}

?>
<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$id=$_GET['idPan'];
        $idProd=$_GET['idProd'];
		$query_search = "DELETE FROM `comporte` WHERE `comporte`.`idProduct` = '$idProd' AND `comporte`.`idPanier` = '$id'";
	    $result = mysqli_query($dbc, $query_search);

		if($result!=0)
		{
            echo"delete done!!";

        }

}
mysqli_close($dbc);
}
?>


<?php
$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="agriapp";
$con=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);
if($con){
    echo"connection success";
    
$query=mysqli_query($con,"Select * From engrais Where idEngrais=14");
   if($query)
{
    while($row=mysqli_fetch_array($query))
    {
        $flag[]=$row;
    }
    print(json_encode($flag));
}

}

?>
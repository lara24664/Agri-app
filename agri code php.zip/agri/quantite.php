<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$name=$_GET['name'];
		$query_search = "select quantity from product where name='$name'";
	$result = @mysqli_query($dbc, $query_search);
			//echo "ok";
		
		//	echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			$rows = array();

// iterate to query result and add every rows into array
while($row = mysqli_fetch_array($result)) {
//$rows[]=$row;
echo $row['quantity'];

}

// close the database connection
mysqli_close($dbc);

// echo the application data in json format
//echo json_encode($rows);
}
	}
}
?>
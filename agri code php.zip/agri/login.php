<?php

if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
        $password = $_GET['password'];
        $username = $_GET['username'];
		$query_search = "SELECT isAdmin FROM `client` WHERE  userName = '$username' AND password='$password'";
		$result = @mysqli_query($dbc, $query_search);
		if(@mysqli_num_rows($result) > 0)
		{
            //$rows = array();
while($row = mysqli_fetch_array($result)) {
echo $row['isAdmin'];
			 //echo "Login Successfully";
		}
        }
        
	else echo "error"; 
@mysqli_close($dbc);
	}
}
?>
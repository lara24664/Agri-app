<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$sellerName=$_GET['sellerName'];
		$query_search = "select name,nbOfBuy from product where sellerUserName='$sellerName'";
		if($result = @mysqli_query($dbc, $query_search))
		{
			if(@mysqli_num_rows($result) > 0)
			{
			
				while($row = mysqli_fetch_array($result))
				{

					echo $row['name']."<".$row['nbOfBuy'].">";
				}
			}
		}
		else
		{
			echo mysqli_error($dbc);
		}
	}
	else
	{
		echo mysqli_error($dbc);
	}
	mysqli_close($dbc);
}
else
{
	echo mysqli_error($dbc);
}
?>
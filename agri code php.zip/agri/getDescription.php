<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$query_search = "select description from plant";
		$result = @mysqli_query($dbc, $query_search);
		if(@mysqli_num_rows($result) > 0)
		{
			$data=array();
			while($row=mysqli_fetch_array($result))
			{
				//$data[]=$row;
				echo $row['description'].".hihihi.";
			}
		//print (json_encode(array("nurseries"=>$data)));
		//"<".$row['location'].
		}
	else echo "error"; 
@mysqli_close($dbc);
	}
}
?>
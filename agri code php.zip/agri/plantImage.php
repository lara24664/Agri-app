<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$id=$_GET['idPlant'];
		$query_search = "select photo from plant where idPlant2='$id'";
	$result = @mysqli_query($dbc, $query_search);
			//echo "ok";
		
		//else 	echo mysqli_error($dbc);
		if(@mysqli_num_rows($result) > 0)
		{
			$rows = array();

// iterate to query result and add every rows into array
while($row = mysqli_fetch_array($result)) {
//$rows[]=$row;
   // header("Content-type:image/jpeg");
echo $row['photo'];

}

// close the database connection
mysqli_close($dbc);

// echo the application data in json format
//echo json_encode($rows);
}
else
	 echo "no";
	}
}
?>

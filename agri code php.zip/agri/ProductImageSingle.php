<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		$name=$_GET['name'];
		$query_search = "select `photo` from `product` where name='$name'";
	$result = @mysqli_query($dbc, $query_search);
			//echo "ok";
		
		if(@mysqli_num_rows($result) > 0)
		{
			//echo"you have data";

// iterate to query result and add every rows into array
while($row = mysqli_fetch_array($result)) {
//$rows[]=$row;
echo $row['photo'];

}

mysqli_close($dbc);


}
	}
}
?>
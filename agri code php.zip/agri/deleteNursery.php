<?php
if ($dbc = @mysqli_connect('localhost','root',''))
{
	if( $db=mysqli_select_db($dbc,'agriapp'))
	{
		if(isset($_GET['name']))
		{
			$query_search = "delete from nurseries where name='{$_GET['name']}'";
			if(@mysqli_query($dbc, $query_search))
			{
				echo "Delete Successfully";
			}
			else echo mysqli_error($dbc); 
		}
		else echo "Delete Failed";
	}
	else echo mysqli_error($dbc);
	@mysqli_close($dbc);
}
else echo mysqli_error($dbc);
?>